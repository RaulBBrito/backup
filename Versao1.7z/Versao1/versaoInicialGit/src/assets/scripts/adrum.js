window['adrum-start-time'] = new Date().getTime();
    (function(config){
        config.appKey = 'teste';
        config.adrumExtUrlHttp = 'http://cdn.appdynamics.com';
        config.adrumExtUrlHttps = 'https://cdn.appdynamics.com';
        config.beaconUrlHttp = 'https://eum.portoseguro.com.br';
        config.beaconUrlHttps = 'https://eum.portoseguro.com.br';
        config.xd = {enable : false};
        config.spa = {"spa2": true};
        config.isZonePromise=true;
      })(window['adrum-config'] || (window['adrum-config'] = {}));