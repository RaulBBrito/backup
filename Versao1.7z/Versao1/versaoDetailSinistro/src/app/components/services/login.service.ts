import { Injectable, EventEmitter } from '@angular/core';
import { User } from '../../_model/user.model';
import { Router } from '@angular/router';

import { HttpClient, HttpHeaders } from '@angular/common/http'; 
import { BehaviorSubject, Observable } from 'rxjs';
import { MessageError } from '../../Util/MessageError';

const httpOptions = {
  headers: new HttpHeaders({'Content-Type': 'application/json'})
};
const apiUrl = 'https://192.167.1.3:8015/automovel/soma/autenticacao/v1/login';

@Injectable({ providedIn: 'root' })
export class LoginService {

  message_error = "";

   mostrarMenuEmitter = new EventEmitter<boolean>();
  private currentUserSubject: BehaviorSubject<User>;
  public currentUser: Observable<User>;

  constructor(private router: Router, 
              private http: HttpClient) {
    
        this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('currentUser')));
        this.currentUser = this.currentUserSubject.asObservable();
   }

   public get currentUserValue(): User {
    return this.currentUserSubject.value;
  }

  logout() {
    localStorage.removeItem('currentUser');
    this.currentUserSubject.next(null);
  }

  getUserDetails(user: User){
    let apiURL = `${apiUrl}?username=${user.username}&password=${user.password}`;
        return this.http.post<any>(apiURL, {});
  }

  onSuccess(data){
    localStorage.setItem('currentUser', JSON.stringify(data));
    this.currentUserSubject.next(data);
    this.router.navigate(['/dashboard']); 
    location.reload();
  }

  handleError(response){
    return response.error.mensagem;
  }

  getMessageError(){
    return this.message_error;
  }

}
