import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable} from 'rxjs';
import { map } from 'rxjs/operators';
import { Vistoria } from '../../_model/vistoria.model';

const apiUrl = 'https://192.167.1.3:8015/';

@Injectable({
  providedIn: 'root'
})
export class VistoriaService {

  private vistoriasSubject: BehaviorSubject<Vistoria[]>;
  public vistorias: Observable<Vistoria[]>;
  private vistoriasTransmitidasSubject: BehaviorSubject<Vistoria[]>;
  public vistoriasTransmitidas: Observable<Vistoria[]>;

  allVistorias: Vistoria[];

  constructor(private http: HttpClient) { 
    this.vistoriasSubject = new BehaviorSubject<Vistoria[]>(JSON.parse(localStorage.getItem('allVistoria')));
    this.vistorias = this.vistoriasSubject.asObservable();

    this.vistoriasTransmitidasSubject = new BehaviorSubject<Vistoria[]>(JSON.parse(localStorage.getItem('allVistoriaTransmitidas')));
    this.vistoriasTransmitidas = this.vistoriasTransmitidasSubject.asObservable();
  }

  getAllVistoria_old(){
    let apiURL = `${apiUrl}automovel/soma/vistorias/v1/vistorias`;
        return this.http.post<any>(apiURL, {});
  }

  getAllVistoria(): Observable<Vistoria[]> {
    let apiURL = `${apiUrl}automovel/soma/vistorias/v1/vistorias`;
        return this.http.post<any>(apiURL, {});

  }
  
  getTransmitVistoria(){
    let apiURL = `${apiUrl}automovel/soma/vistorias/v1/vistorias-transmitidas`;
        return this.http.post<Vistoria[]>(apiURL, {});
  }

  setAll(dados: any){   
    
    localStorage.setItem('allVistoria', JSON.stringify(dados)); 
  }

  setAllTransmitidas(dados: any){   
    
    localStorage.setItem('allVistoriaTransmitidas', JSON.stringify(dados)); 
  }

  getAll(): Vistoria[]{  

    var getVistoria: Vistoria[];

    this.vistorias.forEach(function (vistoria){
      getVistoria = vistoria
    });
    return getVistoria;
  }

  getAllTransmitidas(): Vistoria[]{  

    var getVistoriaTransmitidas: Vistoria[];

    this.vistoriasTransmitidas.forEach(function (vistoria){
      getVistoriaTransmitidas = vistoria
    });
    return getVistoriaTransmitidas;
  }

  pendentesNotRead(){    
    //this.allVistorias = this.allVistorias.filter((vistoria) => vistoria.id === 2);
    //return this.allVistorias;
  }



}
