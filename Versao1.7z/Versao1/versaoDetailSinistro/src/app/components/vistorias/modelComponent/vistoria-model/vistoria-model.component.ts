import { Component, OnInit, Input } from '@angular/core';
import { Vistoria } from '../../../../_model/vistoria.model';

@Component({
  selector: 'soma-vistoria-model',
  templateUrl: './vistoria-model.component.html',
  styleUrls: ['./vistoria-model.component.css']
})
export class VistoriaModelComponent implements OnInit {

  @Input() vistoria: Vistoria;

  constructor() { }

  ngOnInit() {
  }

}
