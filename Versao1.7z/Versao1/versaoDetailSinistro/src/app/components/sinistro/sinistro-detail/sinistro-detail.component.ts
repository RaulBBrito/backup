import { Component, OnInit} from '@angular/core';

@Component({
  selector: 'soma-sinistro-detail',
  templateUrl: './sinistro-detail.component.html',
  styleUrls: ['./sinistro-detail.component.css']
})
export class SinistroDetailComponent implements OnInit {

  panelOpenState = false;

  constructor() { }

  ngOnInit() {
  }

}
