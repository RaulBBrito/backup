import { Component, OnInit } from '@angular/core';
import { LoginService } from '../../services/login.service'; 
import { Router } from '@angular/router';
import { User } from '../../../_model/user.model';
import { SidenavComponent } from '../sidenav/sidenav.component';

@Component({
  selector: 'soma-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  currentUser: User;
  isLogoOpenDesk: boolean = false;

  constructor(private autService: LoginService, private router: Router,
    private sidenav: SidenavComponent){
    this.autService.currentUser.subscribe(x => this.currentUser = x);
    
    //this.isLogoOpenDesk = this.sidenav.isOpenMenu();
    //console.log("HEADER: "+this.isLogoOpenDesk);
  }

  ngOnInit() {
    this.autService.currentUser.subscribe(x => this.currentUser = x);
    
  }

  logout(){
    this.autService.logout();
    this.router.navigate(['/login']);
  }

}
