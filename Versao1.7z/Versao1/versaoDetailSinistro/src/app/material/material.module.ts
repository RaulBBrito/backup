import { NgModule } from '@angular/core';
import {MatButtonModule,
  MatInputModule,
  MatRippleModule,
  MatFormFieldModule,
  MatTooltipModule,
  MatSelectModule,
  MatCardModule,
  MatCheckboxModule,
  MatToolbarModule,
  MatIconModule,
  MatSidenavModule,
  MatGridListModule, 
  MatListModule,
  MatDialogModule,
  MatExpansionModule
} from '@angular/material';

const material = [
    MatButtonModule,
    MatInputModule,
    MatRippleModule,
    MatFormFieldModule,
    MatTooltipModule,
    MatSelectModule,
    MatCardModule,
    MatCheckboxModule,
    MatToolbarModule,
    MatIconModule,
    MatSidenavModule,
    MatGridListModule, 
    MatListModule,
    MatDialogModule,
    MatExpansionModule
];

@NgModule({
  imports: [material],
  exports: [material]
})
export class MaterialModule { }
