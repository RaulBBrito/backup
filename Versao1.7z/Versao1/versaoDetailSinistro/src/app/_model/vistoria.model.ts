export class Vistoria {
    idd: number;
    id: 1;
    numeroSinistro:  string ;
    status : 0;
    dataAgendamento : string ;
    dataLocal :  string ;
    logoSeguradora :  string ;
    tipoVistoria :  0 ;
    oficina : {
       nome :  string ;
       endereco :  string ;
       cep :  string;
       ddd : string ;
       telefone :  string 
    };
    veiculo : {
       montadora :  string ;
       modelo :  string ;
       placa :  string ;
       cor :  string ;
       ano :  string ;
       anoModelo :  string 
    };
    iconeApolicePremium :  string ;
    revisaoExterna : boolean;
    barColor: string;
    isRead: boolean;
}