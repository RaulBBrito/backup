import { AppPasswordDirective } from './app-password.directive';

describe('AppPasswordDirective', () => {
  it('should create an instance', () => {
    const directive = new AppPasswordDirective();
    expect(directive).toBeTruthy();
  });
});
