import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[somaAppPassword]'
})
export class AppPasswordDirective {

  private _shown = false;

  constructor(private el: ElementRef) {
    this.setup();
  }

  toggle(i: HTMLElement) {
    this._shown = !this._shown;
    if (this._shown) {
      this.el.nativeElement.setAttribute('type', 'text');
      i.innerHTML = 'visibility';
    } else {
      this.el.nativeElement.setAttribute('type', 'password');
      i.innerHTML = 'visibility_off';
    }
  }

  setup() {
    const parent = this.el.nativeElement.parentNode;
    const span = document.createElement('span');
    //<span class="icone-eye"></span>
    span.className = `material-icons right`;
    span.style.color = `#009AF8`;
    span.style.paddingTop = `3px`;
    span.innerHTML = `visibility_off`;
    span.addEventListener('click', (event) => {
      this.toggle(span);
    });
    parent.appendChild(span);
  }
}
