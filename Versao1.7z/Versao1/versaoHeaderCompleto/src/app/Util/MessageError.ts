export class MessageError {
    codigo: number;
    message: string;
}