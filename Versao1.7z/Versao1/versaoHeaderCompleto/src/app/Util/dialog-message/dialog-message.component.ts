import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'soma-dialog-message',
  templateUrl: './dialog-message.component.html',
  styleUrls: ['./dialog-message.component.css']
})
export class DialogMessageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
