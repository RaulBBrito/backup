import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'soma-menuicones',
  templateUrl: './menuicones.component.html',
  styleUrls: ['./menuicones.component.css']
})
export class MenuiconesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
