import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'soma-sinistro-alerta',
  templateUrl: './sinistro-alerta.component.html',
  styleUrls: ['./sinistro-alerta.component.css']
})
export class SinistroAlertaComponent implements OnInit {

  @Input() info: any[] = [];

  constructor() { }

  ngOnInit() {
  }

}
