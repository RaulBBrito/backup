import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'soma-sinistro-cabecalho',
  templateUrl: './sinistro-cabecalho.component.html',
  styleUrls: ['./sinistro-cabecalho.component.css']
})
export class SinistroCabecalhoComponent implements OnInit {

  xpandStatus=true;
  
  constructor() { }

  ngOnInit() {
  }

}
