import { Component, OnInit} from '@angular/core';

interface InfoSinistro{
    pagamento: string;
    autorizacao: string;
    Beneficios: string;
}

@Component({
  selector: 'soma-sinistro-detail',
  templateUrl: './sinistro-detail.component.html',
  styleUrls: ['./sinistro-detail.component.css']
})
export class SinistroDetailComponent implements OnInit {

  panelOpenState = false;

  tabLoadTimes: Date[] = [];

  isTabsMenus: any[] = [
    {filiado: "Segurado", class: "menu-selecionado", titulo: "Informações Gerais"},
    {filiado: "Terceiro", class: ""},
    {filiado: "Terceiro", class: ""},
  ]

  infoSinistro: InfoSinistro = 
    {pagamento: "Sem pendências",
    autorizacao: "Sim",
    Beneficios: "-"}
  ;

  constructor() { }

  ngOnInit() {
  }

  getTimeLoaded(index: number) {
    
    if (!this.tabLoadTimes[index]) {
      this.tabLoadTimes[index] = new Date();
    }

    return this.tabLoadTimes[index];
  }

}
