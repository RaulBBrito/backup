import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SinistroDetailComponent } from './sinistro-detail.component';

describe('SinistroDetailComponent', () => {
  let component: SinistroDetailComponent;
  let fixture: ComponentFixture<SinistroDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SinistroDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SinistroDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
