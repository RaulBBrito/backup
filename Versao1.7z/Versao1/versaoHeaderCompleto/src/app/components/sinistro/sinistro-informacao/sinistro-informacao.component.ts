import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'soma-sinistro-informacao',
  templateUrl: './sinistro-informacao.component.html',
  styleUrls: ['./sinistro-informacao.component.css']
})
export class SinistroInformacaoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
