import { Component, Input } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { LoginService } from '../../services/login.service'; 
import { Router, Event, NavigationStart, NavigationEnd, NavigationError } from '@angular/router';
import { User } from '../../../_model/user.model';

@Component({
  selector: 'soma-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.css']
})
export class SidenavComponent {

  currentUser: User;
  isMenuOpen: boolean = true;

  @Input() isDetail: boolean = true;

  menuItems = [
    {path: "/vistoria-pendentes/all", title: "Todas Pendentes", totalsinistro: "   6", margin: "margin-count-total-one"},
    {path: "/vistoria-pendentes/unreaded", title: "Pendentes Não Lidas", totalsinistro: "    3", margin: "margin-count-total-two"},
    {path: "/vistoria-pendentes/untransmitted", title: "Não Transmitidas", totalsinistro: "    3", margin: "margin-count-total-three"},
    {path: "/vistoria-transmitidas/transmitted", title: "Transmitidas", totalsinistro: "", margin: ""},
  ]

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches)
    );

    constructor(private breakpointObserver: BreakpointObserver, private autService: LoginService, private router: Router){
      this.autService.currentUser.subscribe(x => this.currentUser = x);

      router.events.subscribe( (event: Event) => {

        if (event instanceof NavigationStart) {
            if(event.url.split('/')[1] === "sinistro"){
              this.isMenuOpen = false;
            }else{
              this.isMenuOpen = true;
            }
        }
  
        if (event instanceof NavigationEnd) {
        }
  
        if (event instanceof NavigationError) {
            //console.log("ERROR: "+event.error);
        }
    });

    }
  
    ngOnInit() {
      this.autService.currentUser.subscribe(x => this.currentUser = x);
    }

    isOpenMenu(){
      return this.isMenuOpen;
    }

}
