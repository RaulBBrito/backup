import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable} from 'rxjs';
import { Vistoria } from '../../_model/vistoria.model';
import { globals } from 'environments/environment';

@Injectable({
  providedIn: 'root'
})
export class VistoriaService {

  apiUrl = globals.url;

  private surveyAllBS: BehaviorSubject<Vistoria[]>;
  public surveyAll: Observable<Vistoria[]>;

  private surveyNotReadBS: BehaviorSubject<Vistoria[]>;
  public surveyNotRead: Observable<Vistoria[]>;

  private surveyUntransmittedBS: BehaviorSubject<Vistoria[]>;
  public surveyUntransmitted: Observable<Vistoria[]>;

  private surveyTransmittedBS: BehaviorSubject<Vistoria[]>;
  public surveyTransmitte: Observable<Vistoria[]>;

  allVistorias: Vistoria[];

  constructor(private http: HttpClient) { 
    this.surveyAllBS = new BehaviorSubject<Vistoria[]>(JSON.parse(localStorage.getItem('surveyAll')));
    this.surveyAll = this.surveyAllBS.asObservable();

    this.surveyNotReadBS = new BehaviorSubject<Vistoria[]>(JSON.parse(localStorage.getItem('surveyNotRead')));
    this.surveyNotRead = this.surveyNotReadBS.asObservable();

    this.surveyUntransmittedBS = new BehaviorSubject<Vistoria[]>(JSON.parse(localStorage.getItem('surveyUntransmitted')));
    this.surveyUntransmitted = this.surveyUntransmittedBS.asObservable();

    this.surveyTransmittedBS = new BehaviorSubject<Vistoria[]>(JSON.parse(localStorage.getItem('surveyTransmitted')));
    this.surveyTransmitte = this.surveyTransmittedBS.asObservable();
  }

  getAllVistoria(): Observable<Vistoria[]> {
    let apiURL = `${this.apiUrl}automovel/soma/vistorias/v1/vistorias`;
        return this.http.post<any>(apiURL, {});
  }
  
  getSurveyTransmitted(){
    let apiURL = `${this.apiUrl}automovel/soma/vistorias/v1/vistorias-transmitidas`;
        return this.http.post<Vistoria[]>(apiURL, {});
  }

  setSurveyAll(dados: any){   
    localStorage.setItem('surveyAll', JSON.stringify(dados)); 
    this.surveyAllBS = new BehaviorSubject<Vistoria[]>(JSON.parse(localStorage.getItem('surveyAll')));
    this.surveyAll = this.surveyAllBS.asObservable();
  }

  setSurveyNotRead(dados: any){   
    localStorage.setItem('surveyNotRead', JSON.stringify(dados)); 
    this.surveyNotReadBS = new BehaviorSubject<Vistoria[]>(JSON.parse(localStorage.getItem('surveyNotRead')));
    this.surveyNotRead = this.surveyNotReadBS.asObservable();
  }

  setSurveyUntransmitted(dados: any){   
    localStorage.setItem('surveyUntransmitted', JSON.stringify(dados)); 
    this.surveyUntransmittedBS = new BehaviorSubject<Vistoria[]>(JSON.parse(localStorage.getItem('surveyUntransmitted')));
    this.surveyUntransmitted = this.surveyUntransmittedBS.asObservable();
  }

  setSurveyTransmitted(dados: any){   
    localStorage.setItem('surveyTransmitted', JSON.stringify(dados)); 
    this.surveyTransmittedBS = new BehaviorSubject<Vistoria[]>(JSON.parse(localStorage.getItem('surveyTransmitted')));
    this.surveyTransmitte = this.surveyTransmittedBS.asObservable();
  }

  getSurveyAll(): Vistoria[]{  
    var listSurveyAll: Vistoria[];
    this.surveyAll.forEach(function (vistoria){
      listSurveyAll = vistoria
    });
    return listSurveyAll;
  }

  getSurveyNotRead(): Vistoria[]{  
    var listSurveyNotRead: Vistoria[];
    this.surveyAll.forEach(function (vistoria){
      listSurveyNotRead = vistoria
    });
    return listSurveyNotRead;
  }

  getSurveyUntransmitted(): Vistoria[]{  
    var listSurveyUntransmitted: Vistoria[];
    this.surveyAll.forEach(function (vistoria){
      listSurveyUntransmitted = vistoria
    });
    return listSurveyUntransmitted;
  }

  getAllTransmitidas(): Vistoria[]{  

    var listSurveyTransmitte: Vistoria[];
    this.surveyTransmitte.forEach(function (vistoria){
      listSurveyTransmitte = vistoria
    });
    return listSurveyTransmitte;
  }

}
