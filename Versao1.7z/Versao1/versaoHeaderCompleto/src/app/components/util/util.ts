export class Util {

    constructor(){}

    getColorHour(currentDate, dataScheduling){

      const difenrencyDate = Math.abs(currentDate - dataScheduling);
      const hour = Math.floor(difenrencyDate / (1000 * 60 * 60));

      if(hour >= 48){
        return "red";
      }else if(hour >= 24 && hour < 48){
        return "orange";
      }else if(hour >= 12 && hour < 24){
        return "green";
      }else if(hour < 12){
        return "blue";
      }else{
        return "grey";
      }  
    }

    getFormatDate(date){
        const data = new Date(date);
      return (
          "0" + data.getDate()).substr(-2) 
          + "/" + ("0" + (data.getMonth() + 1)).substr(-2) 
          + "/" + data.getFullYear();
    }
}
