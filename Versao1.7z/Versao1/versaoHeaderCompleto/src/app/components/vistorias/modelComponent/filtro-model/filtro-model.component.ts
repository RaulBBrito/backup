import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'soma-filtro-model',
  templateUrl: './filtro-model.component.html',
  styleUrls: ['./filtro-model.component.css']
})
export class FiltroModelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
