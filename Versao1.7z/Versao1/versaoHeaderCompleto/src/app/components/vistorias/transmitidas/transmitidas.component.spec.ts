import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TransmitidasComponent } from './transmitidas.component';

describe('TransmitidasComponent', () => {
  let component: TransmitidasComponent;
  let fixture: ComponentFixture<TransmitidasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TransmitidasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TransmitidasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
