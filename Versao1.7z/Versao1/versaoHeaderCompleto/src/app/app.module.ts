import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { RouterModule } from '@angular/router';
import { HttpModule } from '@angular/http';
import { AppRoutingModule } from './app.routing';
import { AppComponent } from './app.component';
import { TrackCapsDirective } from './Util/track-caps.directive';
import { ComponentsModule } from './components/template/components.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginService } from './components/services/login.service'; 
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import 'hammerjs';

import { LoginComponent } from './components/login/login-acesso/login.component';
import { HomeComponent } from './components/home/home-dashboard/home.component';

import { HttpClientModule, /* other http imports */ } from "@angular/common/http";
import { CommonModule } from '@angular/common';
import { LayoutModule } from '@angular/cdk/layout';
import { MaterialModule } from './material/material.module';
import { DialogMessageComponent } from './Util/dialog-message/dialog-message.component';
import { MessageError } from './Util/MessageError';
import { AppPasswordDirective } from './Util/app-password.directive';
import { PendenteComponent } from './components/vistorias/pendente/pendente.component';
import { TransmitidasComponent } from './components/vistorias/transmitidas/transmitidas.component';

import { NgxMaskModule, IConfig } from 'ngx-mask';
import { VistoriaModelComponent } from './components/vistorias/modelComponent/vistoria-model/vistoria-model.component';
import { FiltroModelComponent } from './components/vistorias/modelComponent/filtro-model/filtro-model.component';
import { SinistroDetailComponent } from './components/sinistro/sinistro-detail/sinistro-detail.component';
import { MenuiconesComponent } from './components/sinistro/menuicones/menuicones.component';
import { MenuNavComponent } from './components/sinistro/menu-nav/menu-nav.component';
import { SinistroAlertaComponent } from './components/sinistro/sinistro-alerta/sinistro-alerta.component';
import { SinistroInformacaoComponent } from './components/sinistro/sinistro-informacao/sinistro-informacao.component';

import {DragDropModule} from '@angular/cdk/drag-drop';
import { SinistroCabecalhoComponent } from './components/sinistro/sinistro-cabecalho/sinistro-cabecalho.component';

const maskConfig: Partial<IConfig> = {
  validation: false,
};

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    TrackCapsDirective,
    DialogMessageComponent,
    AppPasswordDirective,
    PendenteComponent,
    TransmitidasComponent,
    VistoriaModelComponent,
    FiltroModelComponent,
    SinistroDetailComponent,
    MenuiconesComponent,
    MenuNavComponent,
    SinistroAlertaComponent,
    SinistroInformacaoComponent,
    SinistroCabecalhoComponent
  ],
  entryComponents: [DialogMessageComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule,
    MaterialModule,
    ComponentsModule,
    BrowserAnimationsModule,
    HttpModule,
    FlexLayoutModule,
    CommonModule,
    FormsModule, 
    ReactiveFormsModule,
    HttpClientModule,
    LayoutModule,
    DragDropModule,
    NgxMaskModule.forRoot(maskConfig),
  ],
  providers: [LoginService, MessageError],
  bootstrap: [AppComponent]
})
export class AppModule { }
