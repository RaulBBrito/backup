import { NgModule } from '@angular/core';
import { CommonModule, } from '@angular/common';
import { BrowserModule  } from '@angular/platform-browser';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './components/login/login-acesso/login.component';
import { HomeComponent } from './components/home/home-dashboard/home.component';
import { PendenteComponent } from './components/vistorias/pendente/pendente.component';
import { TransmitidasComponent } from './components/vistorias/transmitidas/transmitidas.component';
import { SinistroDetalheComponent } from './components/sinistro/sinistro-detalhe/sinistro-detalhe.component';

import { AuthGuard } from './_interceptor/auth.guard';
const appRoutes: Routes =[
  { path: 'login',      component: LoginComponent },
  { path: '',           component: HomeComponent, canActivate: [AuthGuard] },
  { path: 'dashboard',  component: HomeComponent, canActivate: [AuthGuard] },
  { path: 'vistoria-pendentes/:parameter',  component: PendenteComponent, canActivate: [AuthGuard] },
  { path: 'vistoria-transmitidas/:parameter',  component: TransmitidasComponent, canActivate: [AuthGuard] },
  { path: 'sinistro',  component: SinistroDetalheComponent, canActivate: [AuthGuard] },
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [
    CommonModule,
    BrowserModule,
    RouterModule.forRoot(appRoutes, {onSameUrlNavigation: 'reload'})
  ],
  exports: [
  ],
})
export class AppRoutingModule { }