export enum TipoPagamentoEnum {
    SEM_PENDENCIA = "Sem Pendência",
    COM_PENDENCIA = "Com Pendência"
}