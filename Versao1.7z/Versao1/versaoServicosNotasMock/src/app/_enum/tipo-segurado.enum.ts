export enum TipoSeguradoEnum {
    SEGURADO = "Segurado",
    TERCEIRO = "Terceiro",
}