export enum TipoOficinaEnum {
    CONCESSIONARIA = "Concessionaria",
}