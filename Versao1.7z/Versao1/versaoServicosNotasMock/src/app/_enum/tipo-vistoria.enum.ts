export enum TipoVistoriaEnum {
    CONFERENCIA = "Conferência",
    VISTORIA = "Vistoria",
    ESTORNO = "Estorno"
}