import { Injectable, Output } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Apolice } from 'app/_model/sinistro/apolice.model';
import { environment } from 'environments/environment';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, EMPTY} from 'rxjs';
import { InformacaoApolice } from 'app/_model/sinistro/informacao-apolice.model';
import { MatSnackBar } from '@angular/material/snack-bar';

@Injectable({
  providedIn: 'root'
})
export class SinistroService {

  apiUrl = environment.url;

  private apoliceBS: BehaviorSubject<Apolice>;
  public apolice: Observable<Apolice>;

  @Output() informacaoApolice: InformacaoApolice;

  public seguradoTerceiros: Observable<InformacaoApolice>;
  

  constructor(private http: HttpClient, private snackBar: MatSnackBar,) { 
    this.apoliceBS = new BehaviorSubject<Apolice>(JSON.parse(localStorage.getItem('apolice')));
    this.apolice = this.apoliceBS.asObservable();
  }

  getInfomacaoSinistro(nApolice: string): Observable<InformacaoApolice>{ 
    
    const apiURLApolice = `${this.apiUrl}automovel/soma/sinistros/v1/sinistro?numeroSinistro=${nApolice}`; //`http://localhost:3001/sinistro`; //

    return this.http.get<InformacaoApolice>(apiURLApolice, { });

  }

  setInfomacaoSinistroItem(dados: InformacaoApolice){ 
    this.seguradoTerceiros = JSON.parse(JSON.stringify(dados));
  }

  getInfomacaoSinistroItem():  Observable<InformacaoApolice>{  
    
    return this.seguradoTerceiros;
  
  }

  showMessage(msg: string, isError: boolean = false): void{
    this.snackBar.open(msg, 'X', {
      duration: 5000,
      horizontalPosition: "right",
      verticalPosition: "top",
      panelClass: isError ? ['msg-error'] : ['msg-success']
    });
  }

  errorHandler(e: any): Observable<any>{
    this.showMessage('Erro na chamada do API', true);
    return EMPTY;
  }
}
