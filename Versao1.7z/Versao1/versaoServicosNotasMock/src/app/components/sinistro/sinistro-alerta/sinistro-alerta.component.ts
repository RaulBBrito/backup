import { Component, OnInit, Input } from '@angular/core';
import { ApoliceService } from 'app/components/services/apolice.service';
import { Apolice } from 'app/_model/sinistro/apolice.model';
import { TipoPagamentoEnum } from '../../../_enum/tipo-pagamento.enum';

interface IAlertaSeguro{
  pagamento: string;
  autorizacao: string;
  beneficio: string;
}

@Component({
  selector: 'soma-sinistro-alerta',
  templateUrl: './sinistro-alerta.component.html',
  styleUrls: ['./sinistro-alerta.component.css']
})
export class SinistroAlertaComponent implements OnInit {

  @Input() info: IAlertaSeguro = {
    pagamento: "",
    autorizacao: "",
    beneficio: ""
  };

  apolice: Apolice;
  isSeguroAzul: boolean = false; 
  isComPendencia: string = '';

  constructor(private apoliceService: ApoliceService) {
    this.apolice = new Apolice();
   }

  ngOnInit() {
    this.apolice = this.apoliceService.getApoliceItem();
    this.isComPendencia = this.apolice.alertas.pagamento === "COM_PENDENCIA" ? 'text-bold-red' : '';
    this.apolice.alertas.pagamento = TipoPagamentoEnum[this.apolice.alertas.pagamento];    
    this.isSeguroAzul = this.apolice.seguradora === "AZUL";
    

  }

}
