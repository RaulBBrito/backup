import { Component, OnInit, Input } from '@angular/core';

import { ApoliceService } from 'app/components/services/apolice.service';

import { SeguradoTerceiroApolice } from 'app/_model/sinistro/segurado-terceiro-apolice.model';

@Component({
  selector: 'soma-sinistro-informacao',
  templateUrl: './sinistro-informacao.component.html',
  styleUrls: ['./sinistro-informacao.component.css']
})
export class SinistroInformacaoComponent implements OnInit {

  @Input() informacao: SeguradoTerceiroApolice;

  constructor(private apoliceService: ApoliceService) { }

  ngOnInit(){

    
  }


}
