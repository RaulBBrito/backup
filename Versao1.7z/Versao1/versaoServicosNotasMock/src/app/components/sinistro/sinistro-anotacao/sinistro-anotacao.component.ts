import { Component, OnInit, Inject, AfterViewInit, Input } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import * as moment from 'moment';
import { ConfirmationDialogComponent } from './confirmation-dialog/confirmation-dialog.component';
import { AnotacaoService } from 'app/components/services/anotacao.service';
import { Anotacao } from '../../../_model/sinistro/anotacao.model';
import { ApoliceService } from 'app/components/services/apolice.service';
import { User } from 'app/_model/user/user.model';
import { LoginService } from 'app/components/services/login.service';
import { NotaService } from './nota.service';
import { DialogMessageComponent } from 'app/Util/dialog-message/dialog-message.component';

export interface DialogData {
  animal: string;
  name: string;
}

export interface DialogConfirmation {
  response: boolean;
}

export interface EnableFiltro{
  isTodas: boolean;
  isSomaOrcamento: boolean;
  isSeguradora: boolean;
  isSistema: boolean;
}

@Component({
  selector: 'soma-sinistro-anotacao',
  templateUrl: './sinistro-anotacao.component.html',
  styleUrls: ['./sinistro-anotacao.component.css']
})
export class SinistroAnotacoesComponent implements OnInit, AfterViewInit  {

  currentUser: User;
  anotacao: Anotacao;
  response: boolean = false;
  anotationsRequest: Anotacao[] = [];
  allAnotacoes: Anotacao[] = [];
  numeroSinistro: string = "";
  anotacaoNaoLidas: number = 0;

  isEditando: boolean = false;

  public isEnable: EnableFiltro = {
    isTodas: false,
    isSomaOrcamento: true,
    isSeguradora: false,
    isSistema: false
  }


  constructor(
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<SinistroAnotacoesComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    private anotacaoService: AnotacaoService,
    private apolice: ApoliceService,
    private autService: LoginService,
    private notaService: NotaService
    ) {
      this.numeroSinistro = this.apolice.getApoliceItem().sinistro;
      this.autService.currentUser.subscribe(x => this.currentUser = x);

      this.anotationsRequestGet();

      this.notaService.anotacao.asObservable().subscribe(
        data => this.observableNota(data)
      )

      this.notaService.excluirAnotacao.asObservable().subscribe(
        data => this.excluirNota(data)
      )

    }

    ngAfterViewInit() { 
      
    }

  close(): void {

    if(this.anotacao.textoNota == ""){
      this.dialogRef.close();
    }else{

      const dialogConfirm = this.dialog.open(DialogMessageComponent, {
        width: '350px',
        data: {title: "Sair", message: "Deseja salvar o conteúdo antes de sair?"}
      });

      dialogConfirm.afterClosed().subscribe(result => {      
        if(!result) {
          this.anotacao.dataCadastro = ""+ moment(new Date(Date.now())).format('DD/MM/YYYY hh:mm:ss');
          this.anotacao.sinistro = this.numeroSinistro;
          this.anotacaoService.setAnotacao(this.anotacao);
          this.dialogRef.close();
        }else{
          this.addAnotacao();
        };
      });

    }
  }

  ngOnInit() {
    this.clearAnotacao();
    const anotacaoSalva: Anotacao[]  = this.anotacaoService.getAnotacaoStorage();
    
    if(anotacaoSalva != null){
      this.anotacaoService.getAnotacaoStorage().filter(
        anotacao => { (anotacao.sinistro == this.numeroSinistro) ? this.anotacao = anotacao : false }
      );
    }
  }

  observableNota(nota){
  
    

    if(this.anotacao && this.anotacao.textoNota == ""){
      
      if(this.anotacao.textoNota == ""){
        this.anotacao = nota; 
      }

      if(this.anotacao.sinistro != undefined){
        this.isEditando = true;
      }

      this.anotacaoService.editandoAnotacao(nota);

    }else if(this.anotacao && this.anotacao.textoNota != ""){
      const dialogConfirmEditar = this.dialog.open(DialogMessageComponent, {
        width: '480px',
        data: {title: "Editar anotação", message: "Existe um texto em digitação. Para editar outro conteúdo, o texto em digitação será substituído. Deseja continuar?"}
      });

      dialogConfirmEditar.afterClosed().subscribe(result => {      
        if(result) {
          this.anotacao = nota;  
          this.anotacaoService.editandoAnotacao(nota);
        }
      });
    }
    
  }

  filterAnotations(num: number){
    this.isEnable = { isTodas: false,  isSomaOrcamento: false, isSeguradora: false, isSistema: false }
    this.allAnotacoes = [];
    switch (num) {
      case 1:
        this.isEnable.isTodas         = true; this.allNotacoes();
        break;
      case 2:
        this.isEnable.isSomaOrcamento = true; this.notasOrcamento();
        break;
      case 3:
        this.isEnable.isSeguradora    = true; this.notasSeguradora();
        break;  
      case 4:
        this.isEnable.isSistema       = true; this.notasSistema();
        break;
      default:
        this.isEnable = { isTodas: false,  isSomaOrcamento: false, isSeguradora: false, isSistema: false }
        break;
    } 
    this.countAnotacaoNaoLidas();
    this.allAnotacoes.sort ((a, b) => b.id - a.id);
  }

  anotationsRequestGet(){
    this.anotacaoService.getAnotacao().subscribe(data => {
      this.anotationsRequest = [];
      this.anotationsRequest = (JSON.parse(JSON.stringify(data))).filter(nota => nota);
      this.anotationsRequest.sort ((a, b) => b.id - a.id);

      this.notasOrcamento();
      this.countAnotacaoNaoLidas();
    },
    error => this.anotacaoService.errorHandler(error)
    );
  }

  allNotacoes(){
    this.allAnotacoes = [];
    this.allAnotacoes = Object.create(this.anotationsRequest);

  }

  notasOrcamento(){
    this.allAnotacoes = [];
    this.allAnotacoes = Object.create(this.anotationsRequest.filter(nota => (nota.origemNota === "ORCAMENTO")));
  }

  notasSeguradora(){
    this.allAnotacoes = [];
    this.allAnotacoes = Object.create(this.anotationsRequest.filter(nota => (nota.origemNota === "SEGURADORA")));
  }

  notasSistema(){
    this.allAnotacoes = [];
    this.allAnotacoes = Object.create(this.anotationsRequest.filter(nota => (nota.origemNota === "SISTEMA")));
  }

  notasOrcamento_old(): Anotacao{
    
    return {
      id: 3,
      titulo: "Notas de Orcamento",
      dataCadastro: "12/05/2020 13:10:15",
      visivelImpressao: false,
      visivelOficina: false,
      isNotaLida: true,
      origemNota: "ORCAMENTO",
      textoNota: 
      "<p>Mensagem C.N.S. Tipo: 9 - Críticas Internas</p>"
      +"<p>Código: 940 - CHASSI/PLACA RCF INVÁLIDO - BIN</p>"
      +"<p>Valor criticado: 9BHBG51DHP763892</p>"
      +"<p>Valor criticado: 37289387R74039864</p>",
      sinistro: ""
    };
  }

  
  notasSeguradora_old(): Anotacao{
    const anotacao:Anotacao = {
      id: 2,
      titulo: "Notas Seguradora",
      dataCadastro: "28/06/2020 17:40:02",
      visivelImpressao: true,
      visivelOficina: false,
      isNotaLida: false,
      origemNota: "SEGURADORA",
      textoNota: 
      "<p>Mensagem C.N.S. Tipo: 9 - Críticas Internas</p>"
      +"<p>Código: 940 - CHASSI/PLACA RCF INVÁLIDO - BIN</p>"
      +"<p>Valor criticado: 9BHBG51DHP763892</p>"
      +"<p>Valor criticado: 37289387R74039864</p>",
      sinistro: ""
    };

    return anotacao;

  }

  notasSistema_old(): Anotacao{
    
    return {
      id: 4,
      titulo: "Notas do Sistema",
      dataCadastro: "08/10/2020 15:25:44",
      visivelImpressao: true,
      visivelOficina: true,
      isNotaLida: true,
      origemNota: "SISTEMA",
      textoNota: 
      '<p>Mensagem C.N.S. Tipo: 9 - Críticas Internas</br>'
      +'<p>Código: 940 - CHASSI/PLACA RCF INVÁLIDO - BIN</p>'
      +'<p>Valor criticado: 9BHBG51DHP763892</p>'
      +'<p>Valor criticado: 37289387R74039864</p>',
      sinistro: ""
    };
  }

  clearAnotacao(){
    this.anotacao = new Anotacao();

    this.anotacao = {id: 0, titulo: `${this.currentUser.usuario}`, dataCadastro: "", visivelImpressao: false, visivelOficina: true, isNotaLida: true, 
    origemNota: "USER", textoNota: "", sinistro: ""}

    this.isEditando = false;
  }

  excluirNota(data){

    if(data.id != undefined){
    const dialogConfirmExcluir = this.dialog.open(DialogMessageComponent, {
      width: '480px',
      data: {title: "Excluir anotação", message: "Você realmente deseja remover a anotação?"}
    });

    dialogConfirmExcluir.afterClosed().subscribe(result => {      
      if(result) {
       this.allAnotacoes = this.allAnotacoes.filter((nota) => (nota.id !== data.id));
       this.anotationsRequest = this.anotationsRequest.filter((nota) => (nota.id !== data.id));
       this.countAnotacaoNaoLidas(); 
      }
    });
  }

  }

  addAnotacao(){

    if(this.anotacao.textoNota != ""){
      this.anotacao.dataCadastro = ""+ moment(new Date(Date.now())).format('DD/MM/YYYY hh:mm:ss');
      this.maxSortId();
      this.anotacao.sinistro = this.numeroSinistro;

      if(this.isEnable.isSeguradora){
        this.anotacao.origemNota = "SEGURADORA";
      }else if(this.isEnable.isSistema){
        this.anotacao.origemNota = "SISTEMA";
      }if(this.isEnable.isSomaOrcamento){
        this.anotacao.origemNota = "ORCAMENTO";
      }
      
      if(this.isEditando){
        this.allAnotacoes.forEach(nota => {
          if(nota.id == this.anotacao.id && nota.origemNota == this.anotacao.origemNota){
            nota = this.anotacao;
          }
        })
      }else{
        this.allAnotacoes.push(this.anotacao);
      }

      this.allAnotacoes.sort ((a, b) => b.id - a.id);
      this.anotacaoService.removeAnotacao(this.anotacao);
      this.countAnotacaoNaoLidas();
      this.clearAnotacao();
    }else{
      alert('O campo "Nova Anotação" não pode estar em branco!');
    }
  }

  maxSortId(){
    this.anotationsRequest.filter((a, b) => { 
      if(this.anotacao.id <= a.id) {
        this.anotacao.id = (a.id + 1)
      }
      })
  }

  countAnotacaoNaoLidas(){
    this.anotacaoNaoLidas = 0;
    this.allAnotacoes.forEach((a) => (a.isNotaLida) ? this.anotacaoNaoLidas++ : '');
  }

  limpar(){
    /*if(this.isEditando){
      let num: number = 0;
      if(this.isEnable.isTodas) num = 1;
      else if(this.isEnable.isSomaOrcamento) num = 2;
      else if(this.isEnable.isSeguradora) num = 3;
      else if(this.isEnable.isSistema) num = 4;
      
      this.filterAnotations(num);
    }*/
    this.anotacao = this.anotacaoService.getAnotacaoEditado();
    let anotacoes: Anotacao[] = []; 
    let anotacoesRequest: Anotacao[] = []; 
    this.allAnotacoes.forEach((a) => {
      (a.id === this.anotacao.id) ? anotacoes.push(this.anotacao) : anotacoes.push(a)
    });

    this.anotationsRequest.forEach((a) => {
      (a.id === this.anotacao.id) ? anotacoesRequest.push(this.anotacao) : anotacoesRequest.push(a)
    });

    this.allAnotacoes = []; 
    this.allAnotacoes = anotacoes;
    this.anotationsRequest = anotacoesRequest;
    this.anotacaoService.removendoAnotacao();
    this.anotacaoService.removeAnotacao(this.anotacao);
    this.clearAnotacao();
  }
}

