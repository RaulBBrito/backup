import { Injectable } from '@angular/core';
import { Anotacao } from 'app/_model/sinistro/anotacao.model';
import { BehaviorSubject } from 'rxjs';

@Injectable()

@Injectable()
export class NotaService {

  anotacao = new BehaviorSubject(Anotacao);
  excluirAnotacao = new BehaviorSubject(Anotacao);

  constructor() { 
  }

  ngOnInit() {
  }
  
  editar(note){
    this.anotacao.next(note);
  }

  excluir(note){
    this.excluirAnotacao.next(note);
  }


}
