import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SinistroAnotacoesComponent } from './sinistro-anotacao.component';

describe('SinistroAnotacoesComponent', () => {
  let component: SinistroAnotacoesComponent;
  let fixture: ComponentFixture<SinistroAnotacoesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SinistroAnotacoesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SinistroAnotacoesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
