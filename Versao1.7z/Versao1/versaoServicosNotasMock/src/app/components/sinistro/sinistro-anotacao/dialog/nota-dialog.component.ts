import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MatDialogModule, MAT_DIALOG_DATA } from '@angular/material';

export interface DialogData {
  title: string;
  message: string;
}

@Component({
  selector: 'nota-dialog',
  templateUrl: './nota-dialog.component.html',
  providers: [MatDialogModule]
})
export class NotaDialogComponent implements OnInit {
  title: string;
  message: string;
 
  ngOnInit() {

  }

  constructor(
    public dialogRef: MatDialogRef<NotaDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) {
      console.log(this.data)
     }

  onNoClick(): void {
    this.dialogRef.close();
  }

}