import { Component, OnInit} from '@angular/core';
import { ApoliceService } from 'app/components/services/apolice.service';
import { SinistroService } from 'app/components/services/sinistro.service';
import { SeguradoTerceiroApolice } from 'app/_model/sinistro/segurado-terceiro-apolice.model';
import { InformacaoApolice } from 'app/_model/sinistro/informacao-apolice.model';
import { TipoSeguradoEnum } from '../../../_enum/tipo-segurado.enum'
import { Apolice } from 'app/_model/sinistro/apolice.model';
import { Observable } from 'rxjs';

interface InfoSinistro{
    pagamento: string;
    autorizacao: string;
    beneficio: string;
}

@Component({
  selector: 'soma-sinistro-detalhe',
  templateUrl: './sinistro-detalhe.component.html',
  styleUrls: ['./sinistro-detalhe.component.css']
})
export class SinistroDetalheComponent implements OnInit {

  panelOpenState = false;

  tabLoadTimes: Date[] = [];

  isTabsMenus: any[] = [
    {filiado: "Segurado", segurado:"segurado-selecionado"},
    {filiado: "Terceiro", segurado:""},
    {filiado: "Terceiro", segurado:""},
  ]

  public listSeguradoTerceiro: SeguradoTerceiroApolice[] = [];
  public seguradoTerceiros: Observable<InformacaoApolice>;


  constructor(private apoliceService: ApoliceService, private sinistroService: SinistroService) {
   }

  ngOnInit(): void {
    const apolice:Apolice = this.apoliceService.getApoliceItem(); 

    this.sinistroService.getInfomacaoSinistro(apolice.sinistro).subscribe(data => {
      this.getListSeguradoTerceiro(JSON.parse(JSON.stringify(data)));
    },
    error => this.sinistroService.errorHandler(error));
      
  }

  getListSeguradoTerceiro(apolice: InformacaoApolice){
    
      apolice.tipoSinistro = TipoSeguradoEnum[apolice.tipoSinistro];

      this.listSeguradoTerceiro.push(this.getApoliceSegurado(apolice));
  
      apolice.terceiros.filter(
        segurado => {
          segurado.tipoSinistro = TipoSeguradoEnum[segurado.tipoSinistro],
          this.listSeguradoTerceiro.push(segurado)
        }
      );
  }

  getApoliceSegurado(segurado: InformacaoApolice){
    const apoliceSegurado: SeguradoTerceiroApolice = {
      numeroSinistro: segurado.numeroSinistro,
      tipoSinistro: segurado.tipoSinistro,
      modelo: segurado.modelo,
      anoFabricacao: segurado.anoFabricacao,
      anoModelo: segurado.anoModelo,
      naturezaSinsitro: segurado.naturezaSinsitro,
      dataSinistro: segurado.dataSinistro,
      dataAviso: segurado.dataAviso,
      avisadoPor: segurado.avisadoPor,
      placa: segurado.placa,
      condutor: {
          nome: segurado.condutor.nome,
          idade: segurado.condutor.idade,
      },
      evento: segurado.evento,
      danos: segurado.danos,
      local: {
          endereco: segurado.local.endereco,
          bairro: segurado.local.bairro,
          cidade: segurado.local.cidade,
          cep: segurado.local.cep,
          uf: segurado.local.uf,
          }
    };
    return  apoliceSegurado;
  }

  getTimeLoaded(index: number) {
    
    if (!this.tabLoadTimes[index]) {
      this.tabLoadTimes[index] = new Date();
    }

    return this.tabLoadTimes[index];
  }

}
