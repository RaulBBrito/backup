import { Component, OnInit, Input } from '@angular/core';
import { CardVistoria } from '../../../../_model/vistoria/cardVistoria.model';
import { ApoliceService } from 'app/components/services/apolice.service';
import { Apolice } from 'app/_model/sinistro/apolice.model';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { NotasModelComponent } from '../notas-model/notas-model.component';
import { AnotacaoService } from 'app/components/services/anotacao.service';
import { Anotacao } from 'app/_model/sinistro/anotacao.model';

@Component({
  selector: 'soma-vistoria-model',
  templateUrl: './vistoria-model.component.html',
  styleUrls: ['./vistoria-model.component.css']
})
export class VistoriaModelComponent implements OnInit {

  @Input() vistoria: CardVistoria;
  apolice: Apolice;
  anotations: Anotacao[] = [];

  


  data = [
    {id: 1, titulo: 'Registro automático do sistema - 16/09/2020 às 10:31',
      detalhe: [
        {id: 1, item: 'Mensagem C.N.S Tipo: 9 - Críticas Internas'},
        {id: 2, item: 'Código: 940 - CHASSI/PLACA RCV INVÁLIDO - BIN'},
        {id: 3, item: 'Valor criticado: 9BHHBG51DHP763892'},
        {id: 4, item: 'Valor criticado: 37289387R74039864'},
        {id: 5, item: 'Valor criticado: GBD3388'}
      ]
    },

    {id: 1, titulo: 'João da silva - 20/09/2020 às 10:27',
      detalhe: [
        {id: 1, item: 'O código da oficina foi alterado de 878443 para 383445'}
      ]
    },

    {id: 1, titulo: 'Registro automático do sistema - 17/09/2020 às 12:43',
      detalhe: [
        {id: 2, item: 'Atribuido benefício de desconto na franquia'}
      ]
    },

    {id: 1, titulo: 'Registro automático do sistema - 15/09/2020 às 20:35',
      detalhe: [
        {id: 2, item: 'Emissão do laudo - abertura do processo às 15:30h do dia 20/08/2020'},
      ]
    },

    {id: 1, titulo: 'Registro automático do sistema - 14/09/2020 às 12:05',
      detalhe: [
        {id: 2, item: 'Atribuido benefício de desconto parcial (20%) na franquia'}
      ]
    }
  ];

  constructor(private apoliceService: ApoliceService,
              public dialog: MatDialog,
              private anotacaoService: AnotacaoService ) {
   }

  ngOnInit() {
    this.getAnotations();
  }

  obterSinistro(numSinistro){
    this.apoliceService.getApolice(numSinistro);
  }

  openDialog() {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.width = '736px';
    dialogConfig.data = this.anotations;

    const dialogRef = this.dialog.open(NotasModelComponent,  dialogConfig);

  }

  getAnotations(){
    this.anotacaoService.getAnotacao().subscribe(data => {
      this.anotations = [];
      this.anotations = (JSON.parse(JSON.stringify(data))).filter(nota => nota);
      this.anotations.sort ((a, b) => b.id - a.id);
    },
    error => this.anotacaoService.errorHandler(error)
    );
  }
}
