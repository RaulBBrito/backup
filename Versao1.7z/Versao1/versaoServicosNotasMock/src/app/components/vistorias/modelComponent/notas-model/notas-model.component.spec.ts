import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NotasModelComponent } from './notas-model.component';

describe('NotasModelComponent', () => {
  let component: NotasModelComponent;
  let fixture: ComponentFixture<NotasModelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NotasModelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NotasModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
