import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Anotacao } from 'app/_model/sinistro/anotacao.model';

@Component({
  selector: 'soma-notas-model',
  templateUrl: './notas-model.component.html',
  styleUrls: ['./notas-model.component.css']
})
export class NotasModelComponent {

  constructor(
    public dialogRef: MatDialogRef<NotasModelComponent>,
    @Inject(MAT_DIALOG_DATA) public data: Anotacao[]) { }

}
