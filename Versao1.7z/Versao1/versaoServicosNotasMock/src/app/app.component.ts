import { Component, EventEmitter } from '@angular/core';
import { LoginService } from './components/services/login.service';
import { Router  } from '@angular/router';

import { User } from './_model/user/user.model';

export interface DialogData {
  animal: string;
  name: string;
}

@Component({
  selector: 'soma-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  currentUser: User;

  constructor(private autService: LoginService, private router: Router){
    this.autService.currentUser.subscribe(x => this.currentUser = x);      
  }
  ngOnInit(){
    this.autService.currentUser.subscribe(x => this.currentUser = x);    
  }

  logout(){
    this.autService.logout();
    this.router.navigate(['/login']);
  }
}
