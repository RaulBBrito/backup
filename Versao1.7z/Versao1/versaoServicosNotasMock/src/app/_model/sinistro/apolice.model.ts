export class Apolice{
  veiculo: {
    marca: string;
    modelo: string;
    versao: string;
    combustivel: string;
    anoFabricacao: string;
    anoModelo: string;
    placa: string;
    chassi: string;
    motor: string;
    fipe: string;
  }
  modelo: string;
  anoFabricacao: string;
  anoModelo: string;
  placa: string;
  chassi: string;
  motor: string;
  fipe: string;
  apolice: string;
  tipoSinistro: string;
  sinistro: string;
  apolicePremio: boolean;
  autoPremio: boolean;
  referenciada: boolean;
  vistoria: {
    tipo: string;
    descricao: string;
  }
  logoSeguradora: string;
  seguradora: string;
  oficina: {
    nome: string;
    codigo: number,
    tipo: string;
    referenciada: string;
  }
  alertas: {
    pagamento: string;
    autorizacao: boolean;
    beneficio: string;
  } 
}






