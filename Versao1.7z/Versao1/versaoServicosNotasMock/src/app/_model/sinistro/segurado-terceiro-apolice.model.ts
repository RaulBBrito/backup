export class SeguradoTerceiroApolice{
    numeroSinistro: string;
    tipoSinistro: string;
    modelo: string;
    anoFabricacao: string;
    anoModelo: string;
    naturezaSinsitro: string;
    dataSinistro: string;
    dataAviso: string;
    avisadoPor: string;
    placa: string;
    condutor: {
        nome: string;
        idade: number;
    }
    evento: string;
    danos: string;
    local: {
        endereco: string;
        bairro: string;
        cidade: string;
        cep: string;
        uf: string;
        }
}

