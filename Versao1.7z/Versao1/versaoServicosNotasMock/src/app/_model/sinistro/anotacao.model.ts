export class Anotacao 
{
  id: number;
  titulo: string;
  dataCadastro: string;
  visivelImpressao: boolean;
  visivelOficina: boolean;
  isNotaLida: boolean;
  origemNota: string;
  textoNota: string;

  // ADICIONAR MOCK
  sinistro: string;
}
