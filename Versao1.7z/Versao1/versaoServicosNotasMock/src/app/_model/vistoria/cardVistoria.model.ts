export class CardVistoria {
    id: string ;
    numeroSinistro:  string ;
    status : number;
    dataAgendamento : string ;
    dataLocal :  string ;
    logoSeguradora :  string ;
    tipoVistoria :  string; 
    apolicePremio: boolean;
    autoPremio: boolean;
    referenciada: boolean;
    seguradora: string;
    vistoria: {
      tipo: string;
      descricao: string;
    }
    oficina : {
       nome :  string ;
       endereco :  string ;
       cep :  string;
       ddd : string ;
       telefone :  string 
    }
    veiculo : {
       montadora :  string ;
       modelo :  string ;
       placa :  string ;
       cor :  string ;
       ano :  string ;
       anoModelo :  string; 
    }
    iconeApolicePremium :  string;
    revisaoExterna : boolean;
    barColor: string;
    isRead: boolean;
    tipo: string;
}