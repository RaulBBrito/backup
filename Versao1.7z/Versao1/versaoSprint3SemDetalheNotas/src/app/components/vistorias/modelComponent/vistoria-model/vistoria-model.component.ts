import { Component, OnInit, Input } from '@angular/core';
import { CardVistoria } from '../../../../_model/vistoria/cardVistoria.model';
import { ApoliceService } from 'app/components/services/apolice.service';
import { Apolice } from 'app/_model/sinistro/apolice.model';
import { Router } from '@angular/router';

@Component({
  selector: 'soma-vistoria-model',
  templateUrl: './vistoria-model.component.html',
  styleUrls: ['./vistoria-model.component.css']
})
export class VistoriaModelComponent implements OnInit {

  @Input() vistoria: CardVistoria;
  apolice: Apolice;

  constructor(private apoliceService: ApoliceService,private router: Router) {
   }

  ngOnInit() {
  }

  obterSinistro(numSinistro){
    this.apoliceService.getApolice(numSinistro);
  }
}
