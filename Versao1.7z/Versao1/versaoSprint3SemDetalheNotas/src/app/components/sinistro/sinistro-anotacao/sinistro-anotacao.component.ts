import { Component, OnInit, Inject } from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import * as moment from 'moment';

export interface DialogData {
  animal: string;
  name: string;
}

export interface Anotacao {
  id: number;
  title: string;
  dataCadastro: string;
  visivelImpressao: boolean;
  visivelOficina: boolean;
  textNota: string;
  isNotaLida: boolean;
}

export interface EnableFiltro{
  isTodas: boolean;
  isSomaOrcamento: boolean;
  isSeguradora: boolean;
  isSistema: boolean;
}

@Component({
  selector: 'soma-sinistro-anotacao',
  templateUrl: './sinistro-anotacao.component.html',
  styleUrls: ['./sinistro-anotacao.component.css']
})
export class SinistroAnotacoesComponent implements OnInit {

  anotacao: Anotacao;
  
  allAnotacoes: Anotacao[] = [];

  public isEnable: EnableFiltro = {
    isTodas: false,
    isSomaOrcamento: true,
    isSeguradora: false,
    isSistema: false
  }

  constructor(
    public dialogRef: MatDialogRef<SinistroAnotacoesComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) {}

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit() {
    this.clearAnotacao();

    this.allAnotacoes.push(this.notasOrcamento());
  }

  filterAnotations(num: number){
    this.isEnable = { isTodas: false,  isSomaOrcamento: false, isSeguradora: false, isSistema: false }
    this.allAnotacoes = [];
    switch (num) {
      case 1:
        this.isEnable.isTodas = true;
        this.allNotacoes();
        break;
      case 2:
        this.isEnable.isSomaOrcamento = true;
        this.allAnotacoes.push(this.notasOrcamento());
        break;
      case 3:
        this.isEnable.isSeguradora = true;
        this.allAnotacoes.push(this.notasSeguradora());
        break;  
      case 4:
        this.isEnable.isSistema = true;
        this.allAnotacoes.push(this.notasSistema());
        break;
      default:
        this.isEnable = { isTodas: false,  isSomaOrcamento: false, isSeguradora: false, isSistema: false }
        break;
    } 
  }

  allNotacoes(){
    
    this.allAnotacoes = [{
      id: 0,
      title: "Registro automático do sistema",
      dataCadastro: "16/09/2020 10:05:58",
      visivelImpressao: false,
      visivelOficina: true,
      isNotaLida: true,
      textNota: 
      "Mensagem C.N.S. Tipo: 9 - Críticas Internas"
      +"Código: 940 - CHASSI/PLACA RCF INVÁLIDO - BIN"
      +"Valor criticado: 9BHBG51DHP763892"
      +"Valor criticado: 37289387R74039864",
    },
    { id: 1,
      title: "João da Silva",
      dataCadastro: "20/09/2020 08:35:14",
      visivelImpressao: true,
      visivelOficina: false,
      isNotaLida: true,
      textNota: "Código da oficina alterado de 878443 para 383445",
    }];

    this.allAnotacoes.push(this.notasOrcamento());
    this.allAnotacoes.push(this.notasSeguradora());
    this.allAnotacoes.push(this.notasSistema());
  }

  notasOrcamento(): Anotacao{

    const anotacao:Anotacao = {
      id: 2,
      title: "Notas Orcamento",
      dataCadastro: "28/06/2020 17:40:02",
      visivelImpressao: true,
      visivelOficina: false,
      isNotaLida: false,
      textNota: 
      "<p>Mensagem C.N.S. Tipo: 9 - Críticas Internas</p>"
      +"<p>Código: 940 - CHASSI/PLACA RCF INVÁLIDO - BIN</p>"
      +"<p>Valor criticado: 9BHBG51DHP763892</p>"
      +"<p>Valor criticado: 37289387R74039864</p>",
    };

    return anotacao;

  }

  notasSeguradora(): Anotacao{
    
    return {
      id: 3,
      title: "Notas da seguradora",
      dataCadastro: "12/05/2020 13:10:15",
      visivelImpressao: false,
      visivelOficina: false,
      isNotaLida: true,
      textNota: 
      "<p>Mensagem C.N.S. Tipo: 9 - Críticas Internas</p>"
      +"<p>Código: 940 - CHASSI/PLACA RCF INVÁLIDO - BIN</p>"
      +"<p>Valor criticado: 9BHBG51DHP763892</p>"
      +"<p>Valor criticado: 37289387R74039864</p>",
    };
  }

  notasSistema(): Anotacao{
    
    return {
      id: 4,
      title: "Notas do Sistema",
      dataCadastro: "08/10/2020 15:25:44",
      visivelImpressao: true,
      visivelOficina: true,
      isNotaLida: false,
      textNota: 
      '<p>Mensagem C.N.S. Tipo: 9 - Críticas Internas</br>'
      +'<p>Código: 940 - CHASSI/PLACA RCF INVÁLIDO - BIN</p>'
      +'<p>Valor criticado: 9BHBG51DHP763892</p>'
      +'<p>Valor criticado: 37289387R74039864</p>',
    };
  }

  clearAnotacao(){
    this.anotacao = {id: 5, title: "Usuário Logado", dataCadastro: "", visivelImpressao: false, visivelOficina: true, isNotaLida: true, textNota: ""}
  }

  addAnotacao(){
    this.anotacao.dataCadastro = ""+ moment(new Date(Date.now())).format('DD/MM/YYYY hh:mm:ss');
    this.allAnotacoes.push(this.anotacao);
    this.clearAnotacao();
  }

  limpar(){
    this.clearAnotacao();
  }
}

