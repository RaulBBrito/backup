import { Component, OnInit, Input } from '@angular/core';
import * as $ from 'jquery';

export interface Anotacao {
  id: number;
  title: string;
  dataCadastro: string;
  visivelImpressao: boolean;
  visivelOficina: boolean;
  textNota: string;
  isNotaLida: boolean;
}

@Component({
  selector: 'soma-anotacoes',
  templateUrl: './anotacoes.component.html',
  styleUrls: ['./anotacoes.component.css']
})
export class AnotacoesComponent implements OnInit {

  @Input() anotacao: Anotacao;

  constructor() { 
    
  }

  ngOnInit() {
  }

}
