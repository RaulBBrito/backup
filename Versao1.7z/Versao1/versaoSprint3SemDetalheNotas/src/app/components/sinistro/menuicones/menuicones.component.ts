import { Component, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { SinistroAnotacoesComponent } from '../sinistro-anotacao/sinistro-anotacao.component';

@Component({
  selector: 'soma-menuicones',
  templateUrl: './menuicones.component.html',
  styleUrls: ['./menuicones.component.css']
})
export class MenuiconesComponent implements OnInit {

  public notas = {title: "Titulo"}
  public posNotas = {title: ""}

  animal: string;
  name: string;

  constructor(public dialog: MatDialog) { }

  ngOnInit() {
    //this.openNotas();
  }

  openNotas(): void {
    const dialogRef = this.dialog.open(SinistroAnotacoesComponent, {
      width: '1056px',
      height: '550px',
      data: {name: this.name, animal: this.animal}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      this.animal = result;
    });
  }

}
