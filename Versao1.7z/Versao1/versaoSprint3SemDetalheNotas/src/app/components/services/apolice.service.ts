import { Injectable, Output } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Apolice } from 'app/_model/sinistro/apolice.model';
import { environment } from 'environments/environment';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, EMPTY} from 'rxjs';
import { InformacaoApolice } from 'app/_model/sinistro/informacao-apolice.model';
import { map, catchError } from 'rxjs/operators';
import { MatSnackBar } from '@angular/material/snack-bar';

interface InfoSinistro{
  pagamento: string;
  autorizacao: string;
  beneficio: string;
}

@Injectable({
  providedIn: 'root'
})
export class ApoliceService {

  apiUrl = environment.url;

  private apoliceBS: BehaviorSubject<Apolice>;
  public apolice: Observable<Apolice>;

  @Output() informacaoApolice: InformacaoApolice;

  constructor(private http: HttpClient, private router: Router, private snackBar: MatSnackBar,) { 
    this.apoliceBS = new BehaviorSubject<Apolice>(JSON.parse(localStorage.getItem('apolice')));
    this.apolice = this.apoliceBS.asObservable();
  }

  getApolice(nApolice: string){ 
    
    const apiURLApolice = `${this.apiUrl}automovel/soma/sinistros/v1/sinistro/apolice-resumida?numeroSinistro=${nApolice}`; //`http://localhost:3001/apolice`;//

    this.http.get<Apolice>(apiURLApolice, { }).subscribe(data => {
      this.setApolice(data);
      
      this.router.navigate(['sinistro']);
    });
  }

  getInfomacaoApolice(nApolice: string){ 
    
    const apiURLApolice = `${this.apiUrl}automovel/soma/sinistros/v1/sinistro?numeroSinistro=${nApolice}`; //`http://localhost:3001/sinistro`; //

    this.http.get<InformacaoApolice>(apiURLApolice, { }).subscribe(data => {
      this.setInfomacaoApolice(data);
    });
    }

  setApolice(dados: Apolice){   
    localStorage.setItem('apolice', JSON.stringify(dados)); 
    this.apoliceBS = new BehaviorSubject<Apolice>(JSON.parse(localStorage.getItem('apolice')));
    this.apolice = this.apoliceBS.asObservable();
  }

  setInfomacaoApolice(informacao: InformacaoApolice){   
    this.informacaoApolice = JSON.parse(JSON.stringify(informacao));
  }

  getApoliceItem(): Apolice{  
    var apoliceItem: Apolice;

    this.apolice.subscribe( apolice => apoliceItem = apolice );
    
    return apoliceItem;
  }

  showMessage(msg: string, isError: boolean = false): void{
    this.snackBar.open(msg, 'X', {
      duration: 5000,
      horizontalPosition: "right",
      verticalPosition: "top",
      panelClass: isError ? ['msg-error'] : ['msg-success']
    });
  }

  errorHandler(e: any): Observable<any>{
    this.showMessage('Erro na chamada do API', true);
    return EMPTY;
  } 
}
