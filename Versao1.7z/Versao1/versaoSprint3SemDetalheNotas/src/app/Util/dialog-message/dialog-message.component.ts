import { Component, OnInit, Inject } from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

export interface DialogData {
  animal: string;
  name: string;
}

export interface EnableFiltro{
  isTodas: boolean;
  isSomaOrcamento: boolean;
  isSeguradora: boolean;
  isSistema: boolean;
}

@Component({
  selector: 'soma-dialog-message',
  templateUrl: './dialog-message.component.html',
  styleUrls: ['./dialog-message.component.css']
})
export class DialogMessageComponent implements OnInit {



  anotacao: string = "";
  public isEnable: EnableFiltro = {
    isTodas: false,
    isSomaOrcamento: true,
    isSeguradora: false,
    isSistema: false
  }

  constructor(
    public dialogRef: MatDialogRef<DialogMessageComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) {}

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit() {
  }

  filterAnotations(num: number){
    this.isEnable = { isTodas: false,  isSomaOrcamento: false, isSeguradora: false, isSistema: false }

    switch (num) {
      case 1:
        this.isEnable.isTodas = true;
        break;
      case 2:
        this.isEnable.isSomaOrcamento = true;
        break;
      case 3:
        this.isEnable.isSeguradora = true;
        break;  
      case 4:
        this.isEnable.isSistema = true;
        break;
      default:
        this.isEnable = { isTodas: false,  isSomaOrcamento: false, isSeguradora: false, isSistema: false }
        break;
    } 
  }

}
