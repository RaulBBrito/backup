import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig} from '@angular/material/dialog';
import { SinistroAnotacoesComponent } from '../sinistro-anotacao/sinistro-anotacao.component';
import { Router } from '@angular/router';
import { Fotos } from '../../../_model/foto/foto.model';
import { VistoriaFotoService } from 'app/components/foto/vistoria-foto.service';
import { FotoComponent } from 'app/components/foto/foto.component';
import { CardVistoria } from 'app/_model/vistoria/cardVistoria.model';
import { VistoriaService } from 'app/components/services/vistoria.service';
import { ApoliceService } from '../../services/apolice.service';

@Component({
  selector: 'soma-menuicones',
  templateUrl: './menuicones.component.html',
  styleUrls: ['./menuicones.component.css']
})
export class MenuiconesComponent implements OnInit {
  @ViewChild('myButton', { read: false }) public myButtonRef: ElementRef;

  fotos: Fotos[];
  vistoria: CardVistoria;

  public notas = {title: "Titulo"}
  public posNotas = {title: ""}

  animal: string;
  name: string;

  isOpen = false;

  constructor(public dialog: MatDialog, private router: Router,private vistoriaFotos: VistoriaFotoService,
    private vistoriaService: VistoriaService, private apoliceService: ApoliceService) { }

  ngOnInit() {
    //this.openNotas();
    this.openModalFotos();
    this.fotos = this.vistoriaFotos.getFotos(); 
  }

  openNotas(): void {
    let dialogRef = this.dialog.open(SinistroAnotacoesComponent, {
      width: '1056px',
      height: '550px',
      data: {name: this.name, animal: this.animal}
    });

    dialogRef.afterClosed().subscribe(result => {    
      dialogRef.close(); 
      this.dialog.closeAll();
    });
  }

  openModalFotos() {

    const dialogConfig = new MatDialogConfig();
    const sinistro = this.apoliceService.getApoliceItem().sinistro;

    this.vistoriaService.getSurveyAll().forEach(vistoria => {
      if(sinistro === vistoria.numeroSinistro){
        dialogConfig.data = vistoria;
      }
    });

    const dialogRef = this.dialog.open(FotoComponent,  dialogConfig);
    
  }

}
