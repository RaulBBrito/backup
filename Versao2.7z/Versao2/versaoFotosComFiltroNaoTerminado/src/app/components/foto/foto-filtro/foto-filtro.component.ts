import { Component, OnInit, Input } from '@angular/core';
import { VistoriaFotoService } from '../vistoria-foto.service';
import { FilterService } from '../filter.service';

declare const PhotoViewer: any;

@Component({
  selector: 'soma-foto-filtro',
  templateUrl: './foto-filtro.component.html',
  styleUrls: ['./foto-filtro.component.css']
})
export class FotoFiltroComponent implements OnInit {

@Input() srcFoto;
@Input() positionFoto: number;

  fechar;

  constructor(private filterService: FilterService) { }

  ngOnInit() {
    console.log(this.positionFoto);
    
    var items = [],
        options = {
          index: 0,
        };

        items.push({
          src: this.srcFoto //"https://farm1.staticflickr.com/313/31812080833_297acfbbd9_z.jpg",
          //title: $(this).attr('data-title')
        });

     this.fechar = new PhotoViewer(items, options);
     this.filterService.setFilter(this.fechar, this.positionFoto);
  }

  closeFilter(){
    //this.filterService.fecharFilter(1);
    //this.fechar.close();
  }

}
