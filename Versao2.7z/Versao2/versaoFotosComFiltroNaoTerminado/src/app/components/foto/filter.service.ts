import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FilterService {

  fechaFilter = [];

  constructor() { }

  setFilter(filter, positionFoto){
    this.fechaFilter[positionFoto] = filter;
  }

  fecharFilter(positionFoto: number){

    if(this.fechaFilter[positionFoto]){
      this.fechaFilter[positionFoto].close();
      delete this.fechaFilter[positionFoto];
    }

    console.log("Deletado");
    
    
  }
}
