import localePT from '@angular/common/locales/pt';
import localeExtraPT from '@angular/common/locales/extra/pt';

import { BrowserModule } from '@angular/platform-browser';
import { NgModule, LOCALE_ID } from '@angular/core';

import { RouterModule } from '@angular/router';
import { HttpModule } from '@angular/http';
import { AppRoutingModule } from './app.routing';
import { AppComponent } from './app.component';
import { TrackCapsDirective } from './Util/track-caps.directive';
import { ComponentsModule } from './components/template/components.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginService } from './components/services/login.service';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import 'hammerjs';

import { LoginComponent } from './components/login/login-acesso/login.component';
import { HomeComponent } from './components/home/home-dashboard/home.component';

import { HttpClientModule, /* other http imports */ } from "@angular/common/http";
import { CommonModule, registerLocaleData } from '@angular/common';

import { LayoutModule } from '@angular/cdk/layout';
import { MaterialModule } from './material/material.module';
import { DialogMessageComponent } from './Util/dialog-message/dialog-message.component';
import { MessageError } from './Util/MessageError';
import { AppPasswordDirective } from './Util/app-password.directive';
import { PendenteComponent } from './components/vistorias/pendente/pendente.component';
import { TransmitidasComponent } from './components/vistorias/transmitidas/transmitidas.component';

import { NgxMaskModule, IConfig } from 'ngx-mask';
import { VistoriaModelComponent } from './components/vistorias/modelComponent/vistoria-model/vistoria-model.component';
import { FiltroModelComponent } from './components/vistorias/modelComponent/filtro-model/filtro-model.component';
import { SinistroDetalheComponent } from './components/sinistro/sinistro-detalhe/sinistro-detalhe.component';
import { MenuiconesComponent } from './components/sinistro/menuicones/menuicones.component';
import { MenuNavComponent } from './components/sinistro/menu-nav/menu-nav.component';
import { SinistroAlertaComponent } from './components/sinistro/sinistro-alerta/sinistro-alerta.component';
import { SinistroInformacaoComponent } from './components/sinistro/sinistro-informacao/sinistro-informacao.component';

import {DragDropModule} from '@angular/cdk/drag-drop';
import { SinistroCabecalhoComponent } from './components/sinistro/sinistro-cabecalho/sinistro-cabecalho.component';

import { SinistroAnotacoesComponent } from './components/sinistro/sinistro-anotacao/sinistro-anotacao.component';
import { AnotacoesComponent } from './components/sinistro/sinistro-anotacao/anotacoes/anotacoes.component';
import { NotasModelComponent } from './components/vistorias/modelComponent/notas-model/notas-model.component';
import { ConfirmationDialogComponent } from './components/sinistro/sinistro-anotacao/confirmation-dialog/confirmation-dialog.component';
import { NotaService } from './components/sinistro/sinistro-anotacao/nota.service';
import { NotaDialogComponent } from './components/sinistro/sinistro-anotacao/dialog/nota-dialog.component';
import { TemplateComponent } from './components/sinistro/sinistro-anotacao/template/template.component';
import { OficinaDadosComponent } from './components/oficina/oficina-dados/oficina-dados.component';
import { OficinaModalComponent } from './components/oficina/oficina-modal/oficina-modal.component';
import { InputComponent } from './components/util/input/input.component';
import { ListComponent } from './components/util/list/list.component';
import { FotosComponent } from './components/foto/foto-modal/fotos.component';
import { OverlayModule } from '@angular/cdk/overlay';
import { FotoComponent } from './components/foto/foto.component';
import { FotoFiltroComponent } from './components/foto/foto-filtro/foto-filtro.component';

registerLocaleData(localePT, 'pt-BR', localeExtraPT);

const maskConfig: Partial<IConfig> = {
  validation: false,
};

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    TrackCapsDirective,
    DialogMessageComponent,
    AppPasswordDirective,
    PendenteComponent,
    TransmitidasComponent,
    VistoriaModelComponent,
    FiltroModelComponent,
    SinistroDetalheComponent,
    MenuiconesComponent,
    MenuNavComponent,
    SinistroAlertaComponent,
    SinistroInformacaoComponent,
    SinistroCabecalhoComponent,
    SinistroAnotacoesComponent,
    AnotacoesComponent,
    NotasModelComponent,
    ConfirmationDialogComponent,
    NotaDialogComponent,
    TemplateComponent,
    OficinaDadosComponent,
    OficinaModalComponent,
    InputComponent,
    ListComponent,
    FotosComponent,
    FotoComponent,
    FotoFiltroComponent
  ],
  entryComponents: [DialogMessageComponent, SinistroAnotacoesComponent, NotasModelComponent, ConfirmationDialogComponent, NotaDialogComponent, OficinaDadosComponent, FotosComponent, FotoComponent, FotoFiltroComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule,
    MaterialModule,
    ComponentsModule,
    BrowserAnimationsModule,
    HttpModule,
    FlexLayoutModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    LayoutModule,
    DragDropModule,
    OverlayModule,
    NgxMaskModule.forRoot(maskConfig),
  ],
  providers: [LoginService, NotaService,
     MessageError,
     {provide: LOCALE_ID,
      useValue: 'pt-BR'}
    ],
  bootstrap: [AppComponent]
})
export class AppModule { }
