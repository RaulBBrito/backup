import { Component, OnInit, Inject } from '@angular/core';
import { Fotos } from 'app/_model/foto/foto.model';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material';
import { DialogMessageComponent } from 'app/Util/dialog-message/dialog-message.component';

@Component({
  selector: 'soma-deletar-foto',
  templateUrl: './deletar-foto.component.html',
  styleUrls: ['./deletar-foto.component.css']
})
export class DeletarFotoComponent implements OnInit {

  allFotos: Fotos[];
  checkbox = false;

  constructor(
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<DeletarFotoComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
      this.allFotos = data.dados.filter(foto => {
        foto.isSelected = false;
        return foto
      });;


     }

  ngOnInit() {
    console.table(this.allFotos);
    
  }

  close(){
    this.dialogRef.close();
  }

  changed(evt){
    this.allFotos.forEach(foto => {
        foto.isSelected = evt.target.checked;
      return foto;
    });
  }


  selecionarFoto(item){
    this.checkbox = true;
    this.allFotos.forEach(foto => {
      if(item.id === foto.id){
        foto.isSelected = !foto.isSelected;
      }
      if(!foto.isSelected){
        this.checkbox = false;
      }
      return foto;
    });
  }

  deletarFotos(){
    
     const dialogConfirmExcluir = this.dialog.open(DialogMessageComponent, {
      width: '480px',
      data: {title: "Excluir fotos", message: "Tem certeza que deseja excluir a(s) foto(s) selecionada(s)?"}
    });

    dialogConfirmExcluir.afterClosed().subscribe(result => { 

      if(result){
        dialogConfirmExcluir.close();
        this.dialogRef.close();
      }
    });
    
  }
  

}
