import { Component, OnInit } from '@angular/core';
import { Fotos } from '../../../_model/foto/foto.model';
import { VistoriaFotoService } from 'app/components/foto/vistoria-foto.service';
import { VistoriaService } from 'app/components/services/vistoria.service';
import { ApoliceService } from '../../services/apolice.service';
import { SinistroService } from 'app/components/services/sinistro.service';


@Component({
  selector: 'soma-sinistro-foto',
  templateUrl: './sinistro-foto.component.html',
  styleUrls: ['./sinistro-foto.component.css']
})
export class SinistroFotoComponent implements OnInit {
  fotos: Fotos;
  allFotos: Fotos[];
  constructor(
    private vistoriaFotos: VistoriaFotoService,
    private vistoriaService: VistoriaService,
    private apoliceService: ApoliceService,
    private sinistroService: SinistroService
    ){ }

  ngOnInit(){
    this.allFotos = this.vistoriaFotos.getFotos();
    const sinistro = this.apoliceService.getApoliceItem().sinistro;
    if(!this.fotos){
      this.vistoriaService.getSurveyAll().forEach(vistoria => {
        if(sinistro === vistoria.numeroSinistro){
          this.allFotos = vistoria.fotos;
        }
      });
    }
    this.fotos = this.allFotos[0];
  }

  previusPhoto(){
    //Pega o index e passa para a foto anterior
    let index = this.allFotos.indexOf(this.fotos);
    this.fotos = this.allFotos[index-1];
  }

  nextPhoto(){
    //Pega o index e passa para a próxima foto
    let index = this.allFotos.indexOf(this.fotos);
    this.fotos = this.allFotos[index+1];
  }

  openFotos(item){
    this.fotos = item;
  }

  deletePhoto(){
    let dialogRef = this.sinistroService.openDialog({
      hasBackdrop: true,
      dados: this.allFotos
    })

    dialogRef.afterClosed().subscribe(
      () => {
        dialogRef = null
      }
    )
  }
}
