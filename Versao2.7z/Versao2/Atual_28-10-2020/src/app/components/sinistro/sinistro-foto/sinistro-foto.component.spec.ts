import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SinistroFotoComponent } from './sinistro-foto.component';

describe('SinistroFotoComponent', () => {
  let component: SinistroFotoComponent;
  let fixture: ComponentFixture<SinistroFotoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SinistroFotoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SinistroFotoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
