import { Component, OnInit, Input, Output } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { EventEmitter } from 'protractor';

@Component({
  selector: 'soma-input',
  templateUrl: './input.component.html',
  styleUrls: ['./input.component.css']
})
export class InputComponent implements OnInit {
  @Input() label: string;
  @Input() value;
  //@Output() returnValue = new EventEmitter();
  @Input() tipo;
  @Input() fcontrol: FormControl;
  @Input() placeholder: string;

  //Para os campos que puderem ser filtrados
  filteredOptions: Observable<string[]>;
  constructor(){}

  ngOnInit(){}

  formatDate(){
    var month = this.fcontrol.value.getDate()-1;
    var day = this.fcontrol.value.getMonth()+1;
    var year = this.fcontrol.value.getFullYear();
    this.fcontrol.setValue(new Date(year, month, day));
  }
}
