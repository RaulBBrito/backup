import { Component, OnInit } from '@angular/core';
import { LoginService } from '../../services/login.service'; 
import { VistoriaService } from '../../services/vistoria.service';
import { ActivatedRoute } from '@angular/router';
import { CardVistoria } from '../../../_model/vistoria/cardVistoria.model';
import { Util } from '../../util/util';
import {CdkDragDrop, moveItemInArray} from '@angular/cdk/drag-drop';


@Component({
  selector: 'soma-pendente',
  templateUrl: './pendente.component.html',
  styleUrls: ['./pendente.component.css']
})
export class PendenteComponent implements OnInit {

  allVistorias: CardVistoria[];
  cuntVistorias: number = 0;

  constructor(private loginService: LoginService,
              private vistoriaService: VistoriaService,
              private route:  ActivatedRoute){
  }

  ngOnInit() {    

    this.route.params.subscribe((path: any) => {

      var isVistoriaMemory = this.vistoriaService.getSurveyAll();
      
      if(isVistoriaMemory && path.parameter === "all"){
        this.getAddColor(isVistoriaMemory)
      }else if(isVistoriaMemory){
        this.getFilter(path.parameter);
      }else{
        this.vistoriaService.getAllVistoria()
          .subscribe(
            (data)  => {this.vistoriaService.setSurveyAll(data); this.getAddColor(data)},
            (error) => console.log(error)
          );
      }
       
    })    
      
  }

  getAddColor(vistorias){
    const util: Util = new Util();

    this.allVistorias = vistorias.filter(function (survey){

      const dataScheduling = new Date(survey.dataAgendamento).getTime();
      const currentDate = new Date(Date.now()).getTime();
      //const dataScheduling = new Date('2020-09-07 14:49:00').getTime();
      //const currentDate = new Date('2020-09-08 10:49:00').getTime();

      survey.barColor = util.getColorHour(currentDate, dataScheduling);
      survey.dataAgendamento = util.getFormatDate(survey.dataAgendamento);


      //MOCK
        if(survey.id === 1 || survey.id === 2 || survey.id === 3){
          survey.tipo = "unreaded";
        }else if(survey.numeroSinistro === '531202062450' || survey.numeroSinistro === '531202062451' || survey.numeroSinistro === '531202062452'){
          survey.tipo = "untransmitted";
        }

            
      return true;
    });
  }

  getFilter(parameter){

    this.allVistorias = [];
    const util: Util = new Util();

    let all:any[] = [];

    if(parameter === "unreaded"){
      all = this.vistoriaService.getSurveyNotRead();
    }else if(parameter === "untransmitted"){
      all = this.vistoriaService.getSurveyUntransmitted();
    }else{
      all = this.vistoriaService.getSurveyAll();
    }  

    if(all){

        this.allVistorias = all.filter(function (survey){

          const dataScheduling = new Date(survey.dataAgendamento).getTime();
          //const dataLocal = new Date(survey.dataLocal).getTime();
          const currentDate = new Date(Date.now()).getTime();
          
          //EXCLUIR MOCK
          //const dataScheduling = new Date('2020-09-06 12:18:00').getTime();
          //const currentDate = new Date('2020-09-07 12:18:00').getTime();

          survey.barColor = util.getColorHour(currentDate, dataScheduling);
          survey.dataAgendamento = util.getFormatDate(survey.dataAgendamento);      

          //EXCLUIR MOCK (VERIFICAR ROTEIRO PENDENTES NAO LIDAS e NÃO TRANSMITIDAS)
          if(parameter === "unreaded"){
            if(survey.id === 1 || survey.id === 2 || survey.id === 3){
              return true;
            }else{
              return false;
            }
          }else if(parameter === "untransmitted"){
            if(survey.numeroSinistro === '531202062450' || survey.numeroSinistro === '531202062451' || survey.numeroSinistro === '531202062452'){
              return true;
            }else{
              return false;
            }
          }

          return false;
          
        });   

    }else{
      return false;
    }

    //this.cuntVistorias = this.allVistorias.length;
     
  }

  drop(event: CdkDragDrop<string[]>) {

    moveItemInArray(this.allVistorias, event.previousIndex, event.currentIndex);

    if(this.allVistorias[0].tipo === "unreaded"){
      this.vistoriaService.setSurveyNotRead(this.allVistorias);
    }else if(this.allVistorias[0].tipo === "untransmitted"){
      this.vistoriaService.setSurveyUntransmitted(this.allVistorias);
    }else{
      this.vistoriaService.setSurveyAll(this.allVistorias);
    }
  }

}

