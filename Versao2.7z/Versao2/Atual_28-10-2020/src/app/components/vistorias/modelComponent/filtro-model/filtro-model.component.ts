import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { DialogMessageComponent } from 'app/Util/dialog-message/dialog-message.component';


@Component({
  selector: 'soma-filtro-model',
  templateUrl: './filtro-model.component.html',
  styleUrls: ['./filtro-model.component.css']
})
export class FiltroModelComponent implements OnInit {

  @Input() isVisible: boolean = true;
  flagFiltroControler: boolean = false;
  filtroForm: FormGroup;
  empresaOptions = ['74535021000148', '11357709000165', '33624584000125', '49532494000144', '16852210000148', '02012950000161', '62005777000104'];
  
  constructor(fb: FormBuilder,
    public dialog: MatDialog){
    this.filtroForm = fb.group({
      sinistro: new FormControl('', Validators.compose([Validators.pattern('[0-9]+')])),
      oficinaName: new FormControl(),
      oficinaCNPJ: new FormControl('', Validators.compose([Validators.pattern('[0-9]+'), Validators.maxLength(14)])),
      placa: new FormControl('', Validators.compose([Validators.pattern('[0-9A-Za-z]+')])),
      empresa: new FormControl(),
      de: new FormControl(),
      ate: new FormControl()
    });
  }

  ngOnInit() {
  }

  openFilter(){
    this.flagFiltroControler = !this.flagFiltroControler;
  }

  pesquisar(){
    if(this.filtroForm.controls.sinistro.invalid){
      this.dialog.open(DialogMessageComponent, {
        width: '500px',
        data: {title: "Campos Invalidos", message: "O campo Sinistro aceita apenas caracteres numéricos.", acaoFechar: true}
      });
      return null;
    } else if(this.filtroForm.controls.placa.invalid){
      this.dialog.open(DialogMessageComponent, {
        width: '500px',
        data: {title: "Campos Invalidos", message: "O campo Placa aceita apenas letras e caracteres numéricos.", acaoFechar: true}
      });
      return null;
    } else if(this.filtroForm.controls.oficinaCNPJ.invalid){
      this.dialog.open(DialogMessageComponent, {
        width: '500px',
        data: {title: "Campos Invalidos", message: "O campo Oficina CNPJ aceita apenas caracteres numéricos e no máximo 14 digitos.", acaoFechar: true}
      });
    }
    console.log(this.filtroForm.value);
  }

  limpar(){
    this.filtroForm.reset();
  }
}
