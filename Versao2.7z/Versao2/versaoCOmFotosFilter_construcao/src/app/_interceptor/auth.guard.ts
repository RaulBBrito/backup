import { Injectable  } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Event, NavigationStart, NavigationEnd, NavigationError } from '@angular/router';

import { LoginService } from '../components/services/login.service';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {

    isMenuOpen:boolean = false;

    constructor(
        private router: Router,
        private authenticationService: LoginService
    ) {}

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        const currentUser = this.authenticationService.currentUserValue;
        
        if (currentUser) {
            this.isOpenMenu(this.router);            
            return true;
        }

        this.router.navigate(['/login'], { });
        return false;
    }


    isOpenMenu(router){

        router.events.subscribe( (event: Event) => {

            if (event instanceof NavigationStart) {
                if(event.url.split('/')[1] === "sinistro"){
                  this.isMenuOpen =  false;
                }else{
                    this.isMenuOpen = true;
                }
            }
      
            if (event instanceof NavigationEnd) {
                
            }
      
            if (event instanceof NavigationError) {
                //console.log("ERROR: "+event.error);
            }
        });
    }

    getOpenMenu(){
        return this.isMenuOpen;
    }
}