import { Component, OnInit, EventEmitter} from '@angular/core';
import { LoginService } from '../../services/login.service';
import { User } from '../../../_model/user/user.model';

import { MatDialog } from '@angular/material';
import { DialogMessageComponent } from '../../../Util/dialog-message/dialog-message.component';
import { Router } from '@angular/router';

@Component({
  selector: 'soma-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

  usuario: User = new User();
  
  capsOn: boolean = false;

  message_error = "";
  color_message: string = 'blue-color';

  showPassword: boolean = false;

  constructor(private router: Router,
              private loginService: LoginService, 
              public dialog: MatDialog) {
   }

  ngOnInit() {
    if(this.loginService.currentUserValue){
      this.router.navigate(['/']);
    } 
  }

  async loginUser(){
    this.color_message = 'blue-color';
    this.message_error = "Carregando...";
    
    this.loginService.getUserDetails(this.usuario)
    .subscribe(
      (data)  => {  
        this.message_error = ""; 
        this.color_message = 'red-color'; 
        this.loginService.onSuccess(data)},
      (error) => { 
        this.message_error = this.loginService.handleError(error); 
        this.color_message = 'red-color'; }
    );
  }

  passwordIcone(){
    if(this.showPassword){
      this.showPassword = false;
    }
  }

  openDialog(){
    this.dialog.open(DialogMessageComponent);
  }
}
