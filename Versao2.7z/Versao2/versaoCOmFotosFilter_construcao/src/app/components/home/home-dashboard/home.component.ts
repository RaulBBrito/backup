import { Component, OnInit } from '@angular/core';
import { LoginService } from '../../services/login.service';
import { VistoriaService } from '../../services/vistoria.service'; 

@Component({
  selector: 'soma-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private loginService: LoginService, private vistoriaService: VistoriaService){
  }

  allVistorias: any[];

  ngOnInit() { 
    this.vistoriaService.getAllVistoria()
    .subscribe(
      (data)  => this.allVistorias = data,
      (error) => console.log(error)
    );
  }

  allPendentes(){
    this.allVistorias = this.vistoriaService.allVistorias;    
  }

}
