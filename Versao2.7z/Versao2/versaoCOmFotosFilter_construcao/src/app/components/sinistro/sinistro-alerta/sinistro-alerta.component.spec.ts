import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SinistroAlertaComponent } from './sinistro-alerta.component';

describe('SinistroAlertaComponent', () => {
  let component: SinistroAlertaComponent;
  let fixture: ComponentFixture<SinistroAlertaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SinistroAlertaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SinistroAlertaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
