import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Template } from '../../../../_model/sinistro/template.model';
import { environment } from 'environments/environment'; 

@Injectable({
  providedIn: 'root'
})
export class TemplateService {

  private comments: Template[];
  private observableComments: BehaviorSubject<Template[]>; 

  apiUrl = environment.url;

  templateSelecionado = new BehaviorSubject(Template);
  templates = new BehaviorSubject(Template);

  listaTemplate: Template[];

  constructor(private http: HttpClient) {
  }

  getListTemplate(): Observable<Template[]> {
    let apiURL = `${this.apiUrl}automovel/soma/templates/v1/anotacoes`; //`http://localhost:3001/template`; //
        return this.http.get<any>(apiURL, {});
  }

  template(item){
    item = this.listaTemplate.filter((a) => (a.codigo === item));
    this.templateSelecionado.next(item);
  }


}
