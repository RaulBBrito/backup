import { Component, OnInit, Inject, AfterViewInit, Input } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig} from '@angular/material/dialog';
import * as moment from 'moment';
import { ConfirmationDialogComponent } from './confirmation-dialog/confirmation-dialog.component';
import { AnotacaoService } from 'app/components/services/anotacao.service';
import { Anotacao } from '../../../_model/sinistro/anotacao.model';
import { ApoliceService } from 'app/components/services/apolice.service';
import { User } from 'app/_model/user/user.model';
import { LoginService } from 'app/components/services/login.service';
import { NotaService } from './nota.service';
import { DialogMessageComponent } from 'app/Util/dialog-message/dialog-message.component';
import { TemplateService } from './template/template.service';
import { Template } from '../../../_model/sinistro/template.model';
import { NotasModelComponent } from 'app/components/vistorias/modelComponent/notas-model/notas-model.component';

export interface DialogData {
  animal: string;
  name: string;
}

export interface DialogConfirmation {
  response: boolean;
}

export interface EnableFiltro{
  isTodas: boolean;
  isSomaOrcamento: boolean;
  isSeguradora: boolean;
  isSistema: boolean;
}

@Component({
  selector: 'soma-sinistro-anotacao',
  templateUrl: './sinistro-anotacao.component.html',
  styleUrls: ['./sinistro-anotacao.component.css']
})
export class SinistroAnotacoesComponent implements OnInit, AfterViewInit  {

  currentUser: User;
  anotacao: Anotacao;
  response: boolean = false;
  anotationsRequest: Anotacao[] = [];
  allAnotacoes: Anotacao[] = [];
  numeroSinistro: string = "";
  anotacaoNaoLidas: number = 0;

  isEditando: boolean = false;

  public isEnable: EnableFiltro = {
    isTodas: false,
    isSomaOrcamento: true,
    isSeguradora: false,
    isSistema: false
  }


  constructor(
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<SinistroAnotacoesComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    private anotacaoService: AnotacaoService,
    private apolice: ApoliceService,
    private autService: LoginService,
    private notaService: NotaService,
    private templateService: TemplateService
    ) {
      this.numeroSinistro = this.apolice.getApoliceItem().sinistro;
      this.autService.currentUser.subscribe(x => this.currentUser = x);

      this.anotationsRequestGet();
      this.filterAnotations(0);
      this.notaService.anotacao.asObservable().subscribe(
        data => this.observableNota(data)
      )

      this.notaService.excluirAnotacao.asObservable().subscribe(
        data => this.excluirNota(data)
      )

      this.templateService.templateSelecionado.asObservable().subscribe(
        data => this.observableAddTemplate(data)
      )

    }

    ngAfterViewInit() { 
      
    }

  close(): void {
    const notaVazia = this.anotacao.textoNota.trim();
    if(this.anotacao.textoNota == "" || notaVazia.length === 0){
      this.dialogRef.close();
    }else{

        const dialogConfirm = this.dialog.open(DialogMessageComponent, {
          width: '380px',
          data: {title: "Sair", message: "Deseja salvar o conteúdo antes de sair?"}
        });

        dialogConfirm.afterClosed().subscribe(result => {      
          if(!result) {
            const data = moment(new Date(Date.now())).format('DD/MM/YYYY');
            const hora = moment(new Date(Date.now())).format('hh:mm:ss');
            this.anotacao.dataCadastro = `${data} às ${hora}`;
            this.anotacao.sinistro = this.numeroSinistro;
            this.anotacaoService.setAnotacao(this.anotacao);
            this.dialogRef.close();
          }else{
            this.addAnotacao();
          };
        });
    }
  }

  ngOnInit() {
    this.clearAnotacao();
    const anotacaoSalva: Anotacao[]  = this.anotacaoService.getAnotacaoStorage();
    
    if(anotacaoSalva != null){
      this.anotacaoService.getAnotacaoStorage().filter(
        anotacao => { (anotacao.sinistro == this.numeroSinistro) ? this.anotacao = anotacao : false }
      );
    }
  }

  observableAddTemplate(data){
    const template:Template = data;
    if(this.anotacao != undefined && template.codigo !== 0){
      this.anotacao.textoNota += (this.anotacao.textoNota == "") ? '' : '\n\n';
      this.anotacao.textoNota += `${template.texto}`; 
      this.anotacao.textoNota = this.anotacao.textoNota.substring(0, 1500);
    }
  }

  observableNota(nota){
  
    

    if(this.anotacao && this.anotacao.textoNota == ""){
      
      if(this.anotacao.textoNota == ""){
        this.anotacao = nota; 
      }

      if(this.anotacao.sinistro != undefined){
        this.isEditando = true;
      }

      this.anotacaoService.editandoAnotacao(nota);

    }else if(this.anotacao && this.anotacao.textoNota != "" && this.anotacao.id === nota.id){
      this.anotacao = nota; 
    }else if(this.anotacao && this.anotacao.textoNota != ""){
      const dialogConfirmEditar = this.dialog.open(DialogMessageComponent, {
        width: '480px',
        data: {title: "Editar anotação", message: "Existe um texto em digitação. Para editar outro conteúdo, o texto em digitação será substituído. Deseja continuar?"}
      });

      dialogConfirmEditar.afterClosed().subscribe(result => {      
        if(result) {
          
          this.anotacaoService.editandoAnotacao(nota);
          
          this.anotacao = nota;  
          
          
        }
      });
    }
    
  }

  filterAnotations(num: number){
    this.isEnable = { isTodas: false,  isSomaOrcamento: false, isSeguradora: false, isSistema: false }
    this.allAnotacoes = [];
    switch (num) {
      case 1:
        this.isEnable.isTodas         = true; this.allNotacoes();
        break;
      case 2:
        this.isEnable.isSomaOrcamento = true; this.notasOrcamento();
        break;
      case 3:
        this.isEnable.isSeguradora    = true; this.notasSeguradora();
        break;  
      case 4:
        this.isEnable.isSistema       = true; this.notasSistema();
        break;
      default:
        this.isEnable = { isTodas: true,  isSomaOrcamento: false, isSeguradora: false, isSistema: false }
        break;
    } 
    this.countAnotacaoNaoLidas();
    this.allAnotacoes.sort ((a, b) => b.id - a.id);
  }

  anotationsRequestGet(){
    this.anotacaoService.getAnotacao().subscribe(data => {
      this.anotationsRequest = [];
      this.anotationsRequest = (JSON.parse(JSON.stringify(data))).filter(nota => nota);
      this.anotationsRequest.sort ((a, b) => b.id - a.id);

      this.allNotacoes();
      this.countAnotacaoNaoLidas();
    },
    error => this.anotacaoService.errorHandler(error)
    );
  }

  allNotacoes(){
    this.allAnotacoes = [];
    this.allAnotacoes = this.anotationsRequest; //Object.create(this.anotationsRequest);

  }

  notasOrcamento(){
    this.allAnotacoes = [];
    this.allAnotacoes = this.anotationsRequest.filter(nota => (nota.origemNota === "ORCAMENTO"));
  }

  notasSeguradora(){
    this.allAnotacoes = [];
    this.allAnotacoes = this.anotationsRequest.filter(nota => (nota.origemNota === "SEGURADORA"));
  }

  notasSistema(){
    this.allAnotacoes = [];
    this.allAnotacoes = this.anotationsRequest.filter(nota => (nota.origemNota === "SISTEMA"));
  }

  clearAnotacao(){
    this.anotacao = new Anotacao();

    this.anotacao = {id: 0, titulo: `${this.currentUser.usuario}`, dataCadastro: "", visivelImpressao: false, visivelOficina: true, isNotaLida: true, 
    origemNota: "ORCAMENTO", textoNota: "", sinistro: ""}

    this.isEditando = false;
  }

  excluirNota(data){

    if(data.id != undefined){
    const dialogConfirmExcluir = this.dialog.open(DialogMessageComponent, {
      width: '480px',
      data: {title: "Excluir anotação", message: "Você realmente deseja remover a anotação?"}
    });


    dialogConfirmExcluir.afterClosed().subscribe(result => {      
      if(result) {
       this.allAnotacoes = this.allAnotacoes.filter((nota) => (nota.id !== data.id));
       this.anotationsRequest = this.anotationsRequest.filter((nota) => (nota.id !== data.id));
       this.countAnotacaoNaoLidas(); 
      }
      
      const notaVazia: Anotacao = new Anotacao;
      this.notaService.excluir(notaVazia);
      dialogConfirmExcluir.close();
    });
  }

  }

  addAnotacao(){
    const notaVazia = this.anotacao.textoNota.trim();
    if(notaVazia.length !== 0){
      
      const data = moment(new Date(Date.now())).format('DD/MM/YYYY');
      const hora = moment(new Date(Date.now())).format('hh:mm:ss');
      this.anotacao.dataCadastro = `${data} às ${hora}`;

      this.maxSortId();
      this.anotacao.sinistro = this.numeroSinistro;

      if(this.isEnable.isSeguradora){
        this.anotacao.origemNota = "SEGURADORA";
      }else if(this.isEnable.isSistema){
        this.anotacao.origemNota = "SISTEMA";
      }if(this.isEnable.isSomaOrcamento){
        this.anotacao.origemNota = "ORCAMENTO";
      }
      
      if(this.isEditando){
        this.allAnotacoes.forEach(nota => {
          if(nota.id == this.anotacao.id && nota.origemNota == this.anotacao.origemNota){
            nota = this.anotacao;
          }
        })
      }else{
        this.allAnotacoes.push(this.anotacao);
      }

      this.allAnotacoes.sort ((a, b) => b.id - a.id);
      this.anotacaoService.removeAnotacao(this.anotacao);
      this.countAnotacaoNaoLidas();
      this.clearAnotacao();
    }else{
      const dialogConfirmExcluir = this.dialog.open(DialogMessageComponent, {
        width: '480px',
        data: {title: "Campo vazio", message: "O campo Nova Anotação não pode estar em branco!", acaoFechar: true }
      });
    }
  }

  maxSortId(){
    this.allAnotacoes.filter((a, b) => { 
      if(this.anotacao.id <= a.id) {
        this.anotacao.id = (a.id + 1)
      }
      })
  }

  countAnotacaoNaoLidas(){
    this.anotacaoNaoLidas = 0;
    this.allAnotacoes.forEach((a) => (a.isNotaLida) ? this.anotacaoNaoLidas++ : '');
  }

  limpar(){
    /*if(this.isEditando){
      let num: number = 0;
      if(this.isEnable.isTodas) num = 1;
      else if(this.isEnable.isSomaOrcamento) num = 2;
      else if(this.isEnable.isSeguradora) num = 3;
      else if(this.isEnable.isSistema) num = 4;
      
      this.filterAnotations(num);
    }*/
    let anotacaoEditado: Anotacao = this.anotacaoService.getAnotacaoEditado();
    

    if(anotacaoEditado){
      let anotacoes: Anotacao[] = []; 
      let anotacoesRequest: Anotacao[] = []; 

        this.allAnotacoes.forEach((a) => {
          (a.id === anotacaoEditado.id) ? anotacoes.push(anotacaoEditado) : anotacoes.push(a)
        });

        this.anotationsRequest.forEach((a) => {
          (a.id === anotacaoEditado.id) ? anotacoesRequest.push(anotacaoEditado) : anotacoesRequest.push(a)
        });
        
      this.allAnotacoes = []; 
      this.allAnotacoes = anotacoes;
      this.anotationsRequest = anotacoesRequest;
    }

    this.anotacaoService.removendoAnotacao();
    this.anotacaoService.removeAnotacao(this.anotacao);
    this.clearAnotacao();
  }
}

