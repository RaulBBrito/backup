import { Component, OnInit } from '@angular/core';
import { TemplateService } from './template.service';
import { Template } from 'app/_model/sinistro/template.model';

@Component({
  selector: 'soma-template',
  templateUrl: './template.component.html',
  styleUrls: ['./template.component.css']
})
export class TemplateComponent implements OnInit {

  selected = {codigo: 0, nome : "", texto: ""};
  listaTemplate: Template[] = [];

  constructor(private templateService: TemplateService) { 
  }

  ngOnInit() { 
    this.templateService.getListTemplate().subscribe(data => {
      this.listaTemplate = data;
    });
  }

  addTemplate(item) {
    this.templateService.templateSelecionado.next(item);
}

}
