import { Component, OnInit, Input } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Anotacao } from 'app/_model/sinistro/anotacao.model';
import { NotaService } from '../nota.service';

@Component({
  selector: 'soma-anotacoes',
  templateUrl: './anotacoes.component.html',
  styleUrls: ['./anotacoes.component.css']
})
export class AnotacoesComponent implements OnInit {

  @Input() anotacao: BehaviorSubject<Anotacao>;

  constructor(private notaService: NotaService) { 
  }

  ngOnInit() {
  }

  editarNota(note: Anotacao){
    this.notaService.editar(note);   
  }

  excluirNota(note: Anotacao){
    this.notaService.excluir(note);
  }  

}
