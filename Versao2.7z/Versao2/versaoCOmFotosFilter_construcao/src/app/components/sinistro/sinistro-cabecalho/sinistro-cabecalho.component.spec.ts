import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SinistroCabecalhoComponent } from './sinistro-cabecalho.component';

describe('SinistroCabecalhoComponent', () => {
  let component: SinistroCabecalhoComponent;
  let fixture: ComponentFixture<SinistroCabecalhoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SinistroCabecalhoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SinistroCabecalhoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
