import { Component, OnInit } from '@angular/core';
import { ApoliceService } from '../../services/apolice.service';
import { Apolice } from 'app/_model/sinistro/apolice.model';
import { TipoVistoriaEnum } from '../../../_enum/tipo-vistoria.enum';
import { TipoSeguradoEnum } from '../../../_enum/tipo-segurado.enum';
import { TipoOficinaEnum } from '../../../_enum/tipo-oficina.enum';
import { MatDialog } from '@angular/material';
import { OficinaDadosComponent } from '../../oficina/oficina-dados/oficina-dados.component';

@Component({
  selector: 'soma-sinistro-cabecalho',
  templateUrl: './sinistro-cabecalho.component.html',
  styleUrls: ['./sinistro-cabecalho.component.css']
})
export class SinistroCabecalhoComponent implements OnInit {

  xpandStatus=true;
  capsOn = true;

  apolice: Apolice;

  constructor(private apoliceService: ApoliceService,
    private matDialog: MatDialog) { }

  ngOnInit() {
    this.apolice = this.apoliceService.getApoliceItem();    
    this.apolice.vistoria.tipo = TipoVistoriaEnum[this.apolice.vistoria.tipo];
    this.apolice.tipoSinistro = TipoSeguradoEnum[this.apolice.tipoSinistro];
    this.apolice.oficina.tipo = TipoOficinaEnum[this.apolice.oficina.tipo];
  }

  openModal(){
    const dadosOficina = this.matDialog.open(OficinaDadosComponent, {
      width: '1300px',
      data: {}
    });
  }

}
