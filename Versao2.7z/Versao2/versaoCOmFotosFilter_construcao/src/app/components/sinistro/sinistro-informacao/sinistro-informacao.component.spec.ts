import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SinistroInformacaoComponent } from './sinistro-informacao.component';

describe('SinistroInformacaoComponent', () => {
  let component: SinistroInformacaoComponent;
  let fixture: ComponentFixture<SinistroInformacaoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SinistroInformacaoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SinistroInformacaoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
