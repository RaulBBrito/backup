import { Component, OnInit, Input } from '@angular/core';
import { LoginService } from '../../services/login.service';
import { VistoriaService } from '../../services/vistoria.service';
import { CardVistoria } from '../../../_model/vistoria/cardVistoria.model';
import { Util } from '../../util/util';
import {CdkDragDrop, moveItemInArray} from '@angular/cdk/drag-drop';

@Component({
  selector: 'soma-transmitidas',
  templateUrl: './transmitidas.component.html',
  styleUrls: ['./transmitidas.component.css']
})
export class TransmitidasComponent implements OnInit {

  constructor(private loginService: LoginService, private vistoriaService: VistoriaService){
  }

  allVistorias: CardVistoria[];
  cuntVistorias: number = 0;

  @Input() allVistoriasNotRead: any[];  

  ngOnInit() {       
      var isVistoriaMemory = this.vistoriaService.getAllTransmitidas();
      //this.cuntVistorias = isVistoriaMemory.length;

        if(isVistoriaMemory){
          this.getAddColor(isVistoriaMemory)
        }else{
          this.vistoriaService.getSurveyTransmitted()
          .subscribe(
            (data)  => {this.vistoriaService.setSurveyTransmitted(data); this.getAddColor(data)},
            (error) => console.log(error)
          );
        }
       
   
  }

  getAddColor(vistorias){
    const util: Util = new Util();

    this.allVistorias = vistorias.filter(function (survey){
      const dataScheduling = new Date('2020-09-06 12:18:00').getTime();
      const currentDate = new Date('2020-09-07 12:18:00').getTime();

      survey.barColor = "grey";//util.getColorHour(currentDate, dataScheduling);
      survey.dataAgendamento = util.getFormatDate(survey.dataAgendamento);
            
      return true;
    });
  }

  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.allVistorias, event.previousIndex, event.currentIndex);
    this.vistoriaService.setSurveyTransmitted(this.allVistorias);
  }

}


