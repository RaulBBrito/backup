import { Component, OnInit, Input, ElementRef, ViewChild } from '@angular/core';
import { CardVistoria } from '../../../../_model/vistoria/cardVistoria.model';
import { ApoliceService } from 'app/components/services/apolice.service';
import { Apolice } from 'app/_model/sinistro/apolice.model';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { NotasModelComponent } from '../notas-model/notas-model.component';
import { AnotacaoService } from 'app/components/services/anotacao.service';
import { Anotacao } from 'app/_model/sinistro/anotacao.model';
import * as $ from 'jquery';
import { VistoriaFotoService } from '../../../foto/vistoria-foto.service';
import { FotoComponent } from 'app/components/foto/foto.component';

export interface Fotos{
  id: number;
  imagem: string;
  data: string;
  isSelected: boolean;
}

@Component({
  selector: 'soma-vistoria-model',
  templateUrl: './vistoria-model.component.html',
  styleUrls: ['./vistoria-model.component.css']
})
export class VistoriaModelComponent implements OnInit {
  @ViewChild('myButton', { read: false }) public myButtonRef: ElementRef;
  @Input() vistoria: CardVistoria;
  apolice: Apolice;
  anotations: Anotacao[] = [];
  isCarregando: boolean = false;
  isHand: string;

  isOpen = false;

  fotos:Fotos[] = [];

  constructor(private apoliceService: ApoliceService,
              public dialog: MatDialog,
              private anotacaoService: AnotacaoService,
              private vistoriaFotos: VistoriaFotoService) {
              this.isCarregando = false;
   }

  ngOnInit() {
    this.getAnotations();
  }

  obterSinistro(numSinistro){
    this.isCarregando = true;
    this.vistoriaFotos.setFotos(this.vistoria.fotos);
    this.apoliceService.getApolice(numSinistro);
  }

  openDialog() {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.width = '736px';
    dialogConfig.data = this.anotations;

    const dialogRef = this.dialog.open(NotasModelComponent,  dialogConfig);
  }

  getAnotations(){
    this.anotacaoService.getAnotacao().subscribe(data => {
      this.anotations = [];
      this.anotations = (JSON.parse(JSON.stringify(data))).filter(nota => nota);
      this.anotations.sort ((a, b) => b.id - a.id);
    },
    error => this.anotacaoService.errorHandler(error)
    );
  }

  ngAfterViewInit(){

    let vetor = ['a','p'];
    $(document).ready(function(){

      $('a').click(function(){
        //this.isOpen = false;
        });

    vetor.forEach(valor => {
      $(`${valor}`).click(function(){
       // $(this).hide();
        });
    })
    
      
    });
  }


  openModalFotos(vistoria){
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = vistoria;

    const dialogRef = this.dialog.open(FotoComponent,  dialogConfig);
    
  }


  
}
