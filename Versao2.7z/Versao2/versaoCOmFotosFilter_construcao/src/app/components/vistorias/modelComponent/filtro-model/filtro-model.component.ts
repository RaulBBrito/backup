import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'soma-filtro-model',
  templateUrl: './filtro-model.component.html',
  styleUrls: ['./filtro-model.component.css']
})
export class FiltroModelComponent implements OnInit {

  @Input() isVisible: boolean = true;

  constructor() { }

  ngOnInit() {
  }

}
