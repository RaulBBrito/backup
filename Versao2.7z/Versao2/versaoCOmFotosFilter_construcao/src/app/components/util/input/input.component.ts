import { Component, OnInit, Input, Output } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { EventEmitter } from 'protractor';

@Component({
  selector: 'soma-input',
  templateUrl: './input.component.html',
  styleUrls: ['./input.component.css']
})
export class InputComponent implements OnInit {
  @Input() label: string;
  @Input() value;
  //@Output() returnValue = new EventEmitter();
  @Input() tipo;
  @Input() fcontrol: FormControl;

  //Para os campos que puderem ser filtrados
  filteredOptions: Observable<string[]>;
  constructor(){}

  ngOnInit(){}
}
