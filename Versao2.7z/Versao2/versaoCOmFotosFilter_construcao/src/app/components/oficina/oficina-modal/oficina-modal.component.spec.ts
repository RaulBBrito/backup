import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OficinaModalComponent } from './oficina-modal.component';

describe('OficinaModalComponent', () => {
  let component: OficinaModalComponent;
  let fixture: ComponentFixture<OficinaModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OficinaModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OficinaModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
