import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'soma-oficina-modal',
  templateUrl: './oficina-modal.component.html',
  styleUrls: ['./oficina-modal.component.css']
})
export class OficinaModalComponent implements OnInit {
  label: string = "teste";
  constructor() { }

  ngOnInit() {
  }

}
