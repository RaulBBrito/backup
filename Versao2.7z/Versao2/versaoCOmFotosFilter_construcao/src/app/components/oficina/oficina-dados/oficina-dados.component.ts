import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { DialogMessageComponent } from 'app/Util/dialog-message/dialog-message.component';
import { OficinaService } from 'app/components/services/oficina.service';
import { Oficina } from '../../../_model/oficina/oficina.model';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { ApoliceService } from 'app/components/services/apolice.service';

declare var require: any

export interface CidadeGroup{
  estado: string;
  cidades: string[];
}

export const _filter = (opt: string[], value: string): string[] => {
  const filterValue = value.toLowerCase();
  return opt.filter(item => item.toLowerCase().indexOf(filterValue) === 0);
}

export const locais = require('./locais.json');


@Component({
  selector: 'soma-oficina-dados',
  templateUrl: './oficina-dados.component.html',
  styleUrls: ['./oficina-dados.component.css']
})
export class OficinaDadosComponent implements OnInit {
  teste = "";

  //Observable para o campo das cidades
  cidadesOptions: Observable<CidadeGroup[]>;
  //Controler se a vistoria já foi transmitida ou concluida
  vitoriaTransmitidaConcluida: boolean = false;
  //Formulario da oficina (Verificar se consegue usar o (ngModel) junto ao objeto Oficina)
  formularioOficina: FormGroup = new FormGroup({});
  //Objeto Oficina
  oficina: Oficina = new Oficina();
  //Oficina request, verificar necessidade de
  oficinaRequest: Oficina[] = [];
  //Número do sinistro, verificar necessidade de  
  numeroSinistro: string = "";
  
  //Tipos de input, remover
  tipoInput = {
    number: "number",
    text: "text",
    select: "select",
    autocomplete: "autocomplete"
  }
  
  validaCnpjCpf(fcontrol){
    if(fcontrol.value.toString().length > 14){
      return {"cnpjCpf": true};
    }
  }

  //Data, verificar se consegue usar o (ngModel) junto ao objeto Oficina
  data = {
    codigo: {label: "Código", fcontrol: new FormControl({value: ''})},
    cnpjCpf: {label: "CNPJ/CPF*", fcontrol: new FormControl('', Validators.compose([Validators.pattern('[0-9]+'), this.validaCnpjCpf]))},
    razaoSocial: {label: "Razão Social*", fcontrol: new FormControl()},
    nomeDeGuerra: {label: "Nome de Guerra (Fantasia)", fcontrol: new FormControl()},
    cep: {label: "CEP", fcontrol: new FormControl('', Validators.compose([Validators.pattern('[0-9]+')]))},
    endereco: {label: "Endereço*", fcontrol: new FormControl('', Validators.compose([Validators.required]))},
    numero: {label: "Número*", fcontrol: new FormControl('', Validators.compose([Validators.required, Validators.pattern('[0-9]+')]))},
    complemento: {label: "Complemento", fcontrol: new FormControl()},
    uf: {label:"UF*", value: ["AC",
                              "AL",
                              "AP",
                              "AM",
                              "BA",
                              "CE",
                              "DF",
                              "ES",
                              "GO",
                              "MA",
                              "MT",
                              "MS",
                              "MG",
                              "PA",
                              "PB",
                              "PR",
                              "PE",
                              "PI",
                              "RJ",
                              "RN",
                              "RS",
                              "RO",
                              "RR",
                              "SC",
                              "SP",
                              "SE",
                              "TO"], fcontrol: new FormControl('', Validators.required)},
    cidade: {label:"Cidade*", fcontrol: new FormControl('', Validators.compose([Validators.required]))},
    bairro: {label:"Bairro", fcontrol: new FormControl()},
    pontoReferencia: {label: "Ponto de Referência", fcontrol: new FormControl()},
    email: {label: "E-mail", fcontrol: new FormControl('', Validators.compose([Validators.pattern('[^ @]*@[^ @]*')]))},
    tel1ddd: {label: "Telefone 1", fcontrol: new FormControl('', Validators.compose([Validators.pattern('[0-9]+')]))},
    tel1: {label: "", fcontrol: new FormControl('', Validators.compose([Validators.pattern('[0-9]+')]))},
    ramal1: {label: "Ramal", fcontrol: new FormControl('', Validators.compose([Validators.pattern('[0-9]+')]))},
    tel2ddd: {label: "Telefone 2", fcontrol: new FormControl('', Validators.compose([Validators.pattern('[0-9]+')]))},
    tel2: {label: "", fcontrol: new FormControl('', Validators.compose([Validators.pattern('[0-9]+')]))},
    ramal2: {label: "Ramal", fcontrol: new FormControl('', Validators.compose([Validators.pattern('[0-9]+')]))},
    celularddd: {label: "Celular", fcontrol: new FormControl('', Validators.compose([Validators.pattern('[0-9]+')]))},
    celular: {label: "", fcontrol: new FormControl('', Validators.compose([Validators.pattern('[0-9]+')]))},
    nextelddd: {label: "Nextel", fcontrol: new FormControl('', Validators.compose([Validators.pattern('[0-9]+')]))},
    nextel: {label: "", fcontrol: new FormControl('', Validators.compose([Validators.pattern('[0-9]+')]))},
    contato: {label:"Contato", fcontrol: new FormControl()},
    marcasAtendimento: {label: "", value: ["Audi",
                                           "Bentley",
                                           "BMW",
                                           "Chrysler",
                                           "Audi",
                                           "Bentley",
                                           "BMW",
                                           "Chrysler"], fcontrol: new FormControl()}
  }
  cidadeGroups: CidadeGroup[] = locais;
  
  constructor(
    fb: FormBuilder,
    public dialogRef: MatDialogRef<OficinaDadosComponent>,
    public dialog: MatDialog,
    private oficinaService: OficinaService,
    private apolice: ApoliceService
  ){
    //Pega o número do sinistro
    this.numeroSinistro = this.apolice.getApoliceItem().sinistro;
    
    //Pega oque está armazenado no storage
    let oficina = this.oficinaService.getOficinaCerta(this.numeroSinistro);
    //Verifica se há alguma informação da oficina armazenado em storage
    if(oficina !== null){
      this.oficina = oficina;
      for(let i in this.data){
        this.data[i].fcontrol.value = this.oficina[i];
      }
      if(oficina.enviadoPelaSeguradora){
        if(oficina.codigo != "" && oficina.codigo != null && oficina.codigo != undefined){
          this.data.codigo.fcontrol.disable();
        }
        if(oficina.cnpjCpf != "" && oficina.cnpjCpf != null && oficina.cnpjCpf != undefined){
          this.data.cnpjCpf.fcontrol.disable();
        }
        if(oficina.razaoSocial != "" && oficina.razaoSocial != null && oficina.razaoSocial != undefined){
          this.data.razaoSocial.fcontrol.disable();
        }
      }
    } else {
      //Caso não tenha nenhum dado em storage pega pelo mock
      this.OficinaRequestGet();
    }

    //Aplicar regra para bloquear código, cnpj e razao social

    //Caso não tenha sido transmitida a vistoria ou concluida todos os campos são editaveis
    //A não ser pelo cnpj e razão social que será visto em outra regra
    if(this.vitoriaTransmitidaConcluida){
      //Já foi transmitida ou concluída, logo nenhum campo pode ser editado
      for(let i in this.data){
        this.data[i].fcontrol.disable();
      }
    }
    this.data.codigo.fcontrol.disable();


    this.formularioOficina = fb.group({
      codigo: this.data.codigo.fcontrol,
      cnpjCpf: this.data.cnpjCpf.fcontrol,
      razaoSocial: this.data.razaoSocial.fcontrol,
      nomeDeGuerra: this.data.nomeDeGuerra.fcontrol,
      cep: this.data.cep.fcontrol,
      endereco: this.data.endereco.fcontrol,
      numero: this.data.numero.fcontrol,
      complemento: this.data.complemento.fcontrol,
      uf: this.data.uf.fcontrol,
      cidade: this.data.cidade.fcontrol,
      bairro: this.data.bairro.fcontrol,
      pontoReferencia: this.data.pontoReferencia.fcontrol,
      email: this.data.email.fcontrol,
      tel1ddd: this.data.tel1ddd.fcontrol,
      tel1: this.data.tel1.fcontrol,
      ramal1: this.data.ramal1.fcontrol,
      tel2ddd: this.data.tel2ddd.fcontrol,
      tel2: this.data.tel2.fcontrol,
      ramal2: this.data.ramal2.fcontrol,
      celularddd: this.data.celularddd.fcontrol,
      celular: this.data.celular.fcontrol,
      nextelddd: this.data.nextelddd.fcontrol,
      nextel: this.data.nextel.fcontrol,
      contato: this.data.contato.fcontrol
    });
  }

  ngOnInit(){}

  filtroCidadeEstado(){
    this.cidadesOptions = this.formularioOficina.get('cidade').valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value))
    );
  }

  private _filter(value: string): CidadeGroup[]{
    let uf =  this.formularioOficina.value.uf;
    if(uf !== "" && uf !== null && uf !== undefined){
      if(value){
        return this.cidadeGroups
          .map(group => ({estado: group.estado, cidades: _filter(group.cidades, value)}))
          .filter(group => group.estado == uf);
      } else {
        return this.cidadeGroups
          .map(group => ({estado: group.estado, cidades: group.cidades}))
          .filter(group => group.estado == uf);
      }
    } else if(value){
      return this.cidadeGroups
        .map(group => ({estado: group.estado, cidades: _filter(group.cidades, value)}))
        .filter(group => group.cidades.length > 0);
    }
    return this.cidadeGroups;
  }

  Save(){
    let valores =  this.formularioOficina.value;
    let controls = this.formularioOficina.controls;

    //Verifica se os valores obrigatórios foram preenchidos
    if(valores.endereco === "" || valores.numero === "" || valores.uf === "" || valores.cidade === ""){
      //Os campos obrigatórios não foram preenchidos, critica isso
      const dialogConfirm = this.dialog.open(DialogMessageComponent, {
        width: '350px',
        data: {title: "Campos Pendentes", message: "Preecha todos os campos *obrigatórios.", acaoFechar: true}
      });
    } else {
      //Verifica se existe alguma outra critica
      for(let control in controls){
        if(controls[control].invalid){
          //Personaliza a mensagem de erro
          var mensagemPersonalizada = "O campo %s% deve ser preenchido apenas com números.";
          switch(control){
            case "cnpjCpf":
              mensagemPersonalizada = "O campo CNPJ/CPF deve ter no máximo 14 dígitos sendo todos numéricos.";
              break;
            case "cep":
              mensagemPersonalizada = mensagemPersonalizada.replace("%s%", "CEP");
              break;
            case "numero":
              mensagemPersonalizada = mensagemPersonalizada.replace("%s%", "Número");
              break;
            default:
              mensagemPersonalizada = "O campos numéricos devem ser preenchidos apenas com números.";
              break;
          }
          const dialogConfirm = this.dialog.open(DialogMessageComponent, {
            width: '350px',
            data: {title: "Campos Inválidos", message: mensagemPersonalizada, acaoFechar: true}
          });
          return null;
        }
      }
      //Está tudo ok, segue com o processo
      //Salva em local storage
      let oficina:Oficina = valores;
      if(this.data.codigo.fcontrol.disabled){
        oficina.codigo = this.oficina.codigo;
      }
      if(this.data.cnpjCpf.fcontrol.disabled){
        oficina.cnpjCpf = this.oficina.cnpjCpf;
      }
      if(this.data.razaoSocial.fcontrol.disabled){
        oficina.razaoSocial = this.oficina.razaoSocial;
      }
      if(this.oficina.enviadoPelaSeguradora){
        oficina.enviadoPelaSeguradora = true;   
      }
      oficina.sinistro = this.numeroSinistro;
      this.oficinaService.setOficina(oficina);
      this.Close();
    }
  }

  Close(){
    //Apenas fecha
    this.dialogRef.close();
  }

  Cancelar(){
    //Chama o fechar
    this.Close();
  }

  PendenciaPreenchimento():boolean{
    //Verifica se foi digitado todos os campos obrigatórios para liberar o botão de Salvar
    let valores = this.formularioOficina.value;
    if( valores.endereco === "" ||
        valores.numero === "" ||
        valores.uf === "" ||
        valores.cidade === ""
      ){
        return true;
      }
    return false;
  }

  OficinaRequestGet(){
    this.oficinaService.getOficina().subscribe(data => {
      //Mockado para testes apenas, modificar lógica quando for pegar dados no banco de dados
      let oficinas = [];
      if(this.numeroSinistro == "531202062447"){
        data.sinistro = "531202062447";
        oficinas.push(data);
      } else {
        data.sinistro = "531202062448";
        oficinas.push(data);
      }
      var oficinaRequest = oficinas.filter(item => item.sinistro == this.numeroSinistro);
      if(oficinaRequest[0]){
        var oficina = oficinaRequest[0];

        //Coloca os dados no form
        this.data.codigo.fcontrol.setValue(oficina.codigo);
        this.data.cnpjCpf.fcontrol.setValue(oficina.cpfCnpj);
        this.data.razaoSocial.fcontrol.setValue(oficina.razaoSocial);
        this.data.nomeDeGuerra.fcontrol.setValue(oficina.nomeFantasia);
        this.data.cep.fcontrol.setValue(oficina.endereco.cep);
        this.data.endereco.fcontrol.setValue(oficina.endereco.logradouro);
        this.data.numero.fcontrol.setValue(oficina.endereco.numero);
        this.data.complemento.fcontrol.setValue(oficina.endereco.complemento);
        this.data.uf.fcontrol.setValue(oficina.endereco.uf);
        this.data.cidade.fcontrol.setValue(oficina.endereco.cidade);
        this.data.complemento.fcontrol.setValue(oficina.endereco.complemento);
        this.data.bairro.fcontrol.setValue(oficina.endereco.bairro);
        this.data.pontoReferencia.fcontrol.setValue(oficina.endereco.pontoReferencia);
        this.data.contato.fcontrol.setValue(oficina.contato);
        this.data.email.fcontrol.setValue(oficina.emails[0]);
        this.data.tel1ddd.fcontrol.setValue(oficina.telefones[0].ddd);
        this.data.tel1.fcontrol.setValue(oficina.telefones[0].numero);
        this.data.ramal1.fcontrol.setValue(oficina.telefones[0].ramal);
        this.data.celularddd.fcontrol.setValue(oficina.telefones[0].ddd);
        this.data.celular.fcontrol.setValue(oficina.telefones[1].numero);
        this.data.nextelddd.fcontrol.setValue(oficina.telefones[2].ddd);
        this.data.nextel.fcontrol.setValue(oficina.telefones[2].numero);
        
        //Pega todos os valores setados e joga para o storage
        this.data.codigo.fcontrol.enable();
        let oficinaObj: Oficina =  this.formularioOficina.value;
        this.data.codigo.fcontrol.disable();
        oficinaObj.enviadoPelaSeguradora = true;
        oficinaObj.sinistro = this.numeroSinistro;

        this.oficinaService.setOficina(oficinaObj);
        this.oficina = oficinaObj;
        
        //Desabilita os campos que não podem ser editados se eles vierem preenchidos
        if(oficina.codigo != "" && oficina.codigo != null && oficina.codigo != undefined){
          this.data.codigo.fcontrol.disable();
        }
        if(oficina.cpfCnpj != "" && oficina.cpfCnpj != null && oficina.cpfCnpj != undefined){
          this.data.cnpjCpf.fcontrol.disable();
        }
        if(oficina.razaoSocial != "" && oficina.razaoSocial != null && oficina.razaoSocial != undefined){
          this.data.razaoSocial.fcontrol.disable();
        }
        console.log(oficinaObj);

      }
      
    }, error => this.oficinaService.errorHandler(error)
    );
  }
}
