import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OficinaDadosComponent } from './oficina-dados.component';

describe('OficinaDadosComponent', () => {
  let component: OficinaDadosComponent;
  let fixture: ComponentFixture<OficinaDadosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OficinaDadosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OficinaDadosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
