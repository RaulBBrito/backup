import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Anotacao } from '../../_model/sinistro/anotacao.model';
import { BehaviorSubject, Observable, EMPTY} from 'rxjs';
import { environment } from 'environments/environment';
import { MatSnackBar } from '@angular/material/snack-bar';

@Injectable({
  providedIn: 'root'
})
export class AnotacaoService {

  apiUrl = environment.url;

  private annotationsAllBS: BehaviorSubject<Anotacao[]>;
  public annotationsAll: Observable<Anotacao[]>;

  constructor(private http: HttpClient, private snackBar: MatSnackBar) {
    this.atualizarAnotacao();
   }

  setAnotacao(anotacao: Anotacao){
    let annotations: Anotacao[] = [];
    let annotationStorage = this.getAnotacaoStorage();
    
    anotacao.id = this.getCountAnnotations();
    if(annotationStorage != null){

      annotationStorage = annotationStorage.filter(nota => nota.sinistro !== anotacao.sinistro);

      annotationStorage.push(anotacao);

      annotations = annotationStorage;
    }else{
      annotations.push(anotacao);
    }

    localStorage.setItem('annotationsAll', JSON.stringify(annotations)); 
    this.atualizarAnotacao();
  }

  getAnotacao(){
    let apiURL = `${this.apiUrl}automovel/soma/vistorias/v1/anotacoes`; //`http://localhost:3001/anotacao`; //
        return this.http.get<Anotacao>(apiURL, {});
  }

  getAnotacaoStorage(): Anotacao[]{  
    var annotation: Anotacao[] = [];

    annotation = JSON.parse(localStorage.getItem('annotationsAll'));

    return annotation;
  }

  getCountAnnotations(): number{
    var annotation: Anotacao[] = this.getAnotacaoStorage()
    return (annotation == null) ? 1 : annotation.length + 1;
  }

  atualizarAnotacao(){
    this.annotationsAllBS = new BehaviorSubject<Anotacao[]>(JSON.parse(localStorage.getItem('annotationsAll')));
    this.annotationsAll = this.annotationsAllBS.asObservable();
  }

  removeAnotacao(anotacao: Anotacao){
      let annotationStorage = this.getAnotacaoStorage();
      if(annotationStorage != null){
  
        annotationStorage = annotationStorage.filter(nota => nota.sinistro !== anotacao.sinistro);
        
        localStorage.setItem('annotationsAll', JSON.stringify(annotationStorage)); 
        this.atualizarAnotacao();
      }
  
  }

  editandoAnotacao(anotacao){
    localStorage.setItem('anotationEdit', JSON.stringify(anotacao)); 
  }

  removendoAnotacao(){    
    localStorage.removeItem('anotationEdit');
  }

  getAnotacaoEditado(): Anotacao{
    const anotacao:Anotacao = JSON.parse(localStorage.getItem('anotationEdit'));
    return anotacao;
  }

  showMessage(msg: string, isError: boolean = false): void{
    this.snackBar.open(msg, 'X', {
      duration: 5000,
      horizontalPosition: "right",
      verticalPosition: "top",
      panelClass: isError ? ['msg-error'] : ['msg-success']
    });
  }

  errorHandler(e: any): Observable<any>{
    this.showMessage('Erro na chamada do API', true);
    return EMPTY;
  }

}
