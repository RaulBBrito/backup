import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable} from 'rxjs';
import { CardVistoria } from '../../_model/vistoria/cardVistoria.model';
import { environment } from 'environments/environment';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class VistoriaService {

  apiUrl = environment.url;

  private surveyAllBS: BehaviorSubject<CardVistoria[]>;
  public surveyAll: Observable<CardVistoria[]>;

  private surveyNotReadBS: BehaviorSubject<CardVistoria[]>;
  public surveyNotRead: Observable<CardVistoria[]>;

  private surveyUntransmittedBS: BehaviorSubject<CardVistoria[]>;
  public surveyUntransmitted: Observable<CardVistoria[]>;

  private surveyTransmittedBS: BehaviorSubject<CardVistoria[]>;
  public surveyTransmitte: Observable<CardVistoria[]>;

  allVistorias: CardVistoria[];

  constructor(private http: HttpClient, private router: Router) { 
    this.surveyAllBS = new BehaviorSubject<CardVistoria[]>(JSON.parse(localStorage.getItem('surveyAll')));
    this.surveyAll = this.surveyAllBS.asObservable();

    this.surveyNotReadBS = new BehaviorSubject<CardVistoria[]>(JSON.parse(localStorage.getItem('surveyNotRead')));
    this.surveyNotRead = this.surveyNotReadBS.asObservable();

    this.surveyUntransmittedBS = new BehaviorSubject<CardVistoria[]>(JSON.parse(localStorage.getItem('surveyUntransmitted')));
    this.surveyUntransmitted = this.surveyUntransmittedBS.asObservable();

    this.surveyTransmittedBS = new BehaviorSubject<CardVistoria[]>(JSON.parse(localStorage.getItem('surveyTransmitted')));
    this.surveyTransmitte = this.surveyTransmittedBS.asObservable();
  }

  getAllVistoria(): Observable<CardVistoria[]> {
    let apiURL = `${this.apiUrl}automovel/soma/vistorias/v1/vistorias`;
        return this.http.post<any>(apiURL, {});
  }
  
  getSurveyTransmitted(){
    let apiURL = `${this.apiUrl}automovel/soma/vistorias/v1/vistorias-transmitidas`;
        return this.http.post<CardVistoria[]>(apiURL, {});
  }

  setSurveyAll(dados: any){   
    localStorage.setItem('surveyAll', JSON.stringify(dados)); 
    this.surveyAllBS = new BehaviorSubject<CardVistoria[]>(JSON.parse(localStorage.getItem('surveyAll')));
    this.surveyAll = this.surveyAllBS.asObservable();
  }

  setSurveyNotRead(dados: any){   
    localStorage.setItem('surveyNotRead', JSON.stringify(dados)); 
    this.surveyNotReadBS = new BehaviorSubject<CardVistoria[]>(JSON.parse(localStorage.getItem('surveyNotRead')));
    this.surveyNotRead = this.surveyNotReadBS.asObservable();
  }

  setSurveyUntransmitted(dados: any){   
    localStorage.setItem('surveyUntransmitted', JSON.stringify(dados)); 
    this.surveyUntransmittedBS = new BehaviorSubject<CardVistoria[]>(JSON.parse(localStorage.getItem('surveyUntransmitted')));
    this.surveyUntransmitted = this.surveyUntransmittedBS.asObservable();
  }

  setSurveyTransmitted(dados: any){   
    localStorage.setItem('surveyTransmitted', JSON.stringify(dados)); 
    this.surveyTransmittedBS = new BehaviorSubject<CardVistoria[]>(JSON.parse(localStorage.getItem('surveyTransmitted')));
    this.surveyTransmitte = this.surveyTransmittedBS.asObservable();
  }

  getSurveyAll(): CardVistoria[]{  
    var listSurveyAll: CardVistoria[];
    this.surveyAll.forEach(function (vistoria){
      listSurveyAll = vistoria
    });
    return listSurveyAll;
  }

  getSurveyNotRead(): CardVistoria[]{  
    var listSurveyNotRead: CardVistoria[];
    this.surveyAll.forEach(function (vistoria){
      listSurveyNotRead = vistoria
    });
    return listSurveyNotRead;
  }

  getSurveyUntransmitted(): CardVistoria[]{  
    var listSurveyUntransmitted: CardVistoria[];
    this.surveyAll.forEach(function (vistoria){
      listSurveyUntransmitted = vistoria
    });
    return listSurveyUntransmitted;
  }

  getAllTransmitidas(): CardVistoria[]{  

    var listSurveyTransmitte: CardVistoria[];
    this.surveyAll.forEach(function (vistoria){
      listSurveyTransmitte = vistoria
    });
    return listSurveyTransmitte;
  }

  atualizar() {
    localStorage.removeItem('surveyAll');
    this.surveyAllBS.next(null);

    localStorage.removeItem('surveyNotRead');
    this.surveyNotReadBS.next(null);

    localStorage.removeItem('surveyUntransmitted');
    this.surveyUntransmittedBS.next(null);

    localStorage.removeItem('surveyTransmitted');
    this.surveyTransmittedBS.next(null);

    this.router.navigate(['/dashboard']);
  }

}
