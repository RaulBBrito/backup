import { Injectable } from '@angular/core';

import { environment } from 'environments/environment';
import { BehaviorSubject, Observable, EMPTY} from 'rxjs';
import { Oficina } from '../../_model/oficina/oficina.model';
import { HttpClient } from '@angular/common/http';
import { MatSnackBar } from '@angular/material/snack-bar';

@Injectable({
  providedIn: 'root'
})
export class OficinaService {

  apiUrl = environment.url;
  private oficinaAllBS: BehaviorSubject<Oficina[]>;
  public oficinaAll: Observable<Oficina[]>;


  constructor(private http: HttpClient, private snackBar: MatSnackBar){
    this.atualizarOficina();
  }

  getOficina(){
    let apiURL = `${this.apiUrl}automovel/soma/oficinas/v1/oficinas`; //Modificar para o caminho certo
    return this.http.get<Oficina>(apiURL, {});
  }

  setOficina(oficina: Oficina){
    let oficinas: Oficina[] = [];
    let oficinaStorage = this.getOficinaStorage();

    if(oficinaStorage != null && oficinaStorage.length != 0){
      oficinaStorage = oficinaStorage.filter(nota => nota.sinistro !== oficina.sinistro);
      oficinaStorage.push(oficina);
      oficinas = oficinaStorage;
    } else {
      oficinas.push(oficina);
    }
    
    localStorage.setItem('oficinaAll', JSON.stringify(oficinas)); 
    this.atualizarOficina();
  }

  getOficinaStorage(): Oficina[]{
    var oficina: Oficina[] = [];
    oficina = JSON.parse(localStorage.getItem('oficinaAll'));
    return oficina;
  }

  getOficinaCerta(sinistro: string): Oficina{
    let oficinas: Oficina[] = this.getOficinaStorage();
    for(let oficina in oficinas){
      if(oficinas[oficina].sinistro === sinistro){
        return oficinas[oficina];
      }
    }
    return null;
  }

  atualizarOficina(){
    this.oficinaAllBS = new BehaviorSubject<Oficina[]>(JSON.parse(localStorage.getItem('oficinaAll')));
    this.oficinaAll = this.oficinaAllBS.asObservable();
  }

  errorHandler(e: any): Observable<any>{
    this.showMessage('Erro na chamada do API', true);
    return EMPTY;
  }

  showMessage(msg: string, isError: boolean = false): void{
    this.snackBar.open(msg, 'X', {
      duration: 5000,
      horizontalPosition: "right",
      verticalPosition: "top",
      panelClass: isError ? ['msg-error'] : ['msg-success']
    });
  }

  clean(){
    localStorage.setItem('oficinaAll', null); 
  }
}
