import { Component, OnInit } from '@angular/core';

declare const PhotoViewer: any;

@Component({
  selector: 'soma-foto-filtro',
  templateUrl: './foto-filtro.component.html',
  styleUrls: ['./foto-filtro.component.css']
})
export class FotoFiltroComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    var items = [],
        options = {
          index: 0,
        };

        items.push({
          src: "https://farm1.staticflickr.com/313/31812080833_297acfbbd9_z.jpg",
          //title: $(this).attr('data-title')
        });

      new PhotoViewer(items, options);
  }

}
