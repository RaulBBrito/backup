import { ElementRef, Injectable } from '@angular/core'
import { MatDialog, MatDialogRef } from '@angular/material'

import { FotosComponent } from './foto-modal/fotos.component';

export interface Fotos{
  id: number;
  imagem: string;
  data: string;
  isSelected: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class VistoriaFotoService {

  private fotos: Fotos[];
  private vistoria: Fotos[];

  constructor(public dialog: MatDialog) { }

  public openDialog({ positionRelativeToElement, 
    hasBackdrop = false,
    height = '99%', 
    width = '49%',
    dados}:
    {
      positionRelativeToElement: ElementRef, hasBackdrop: boolean,
      height?: string, width?: string, dados: Fotos[]
    }): MatDialogRef<FotosComponent> {

    const dialogRef: MatDialogRef<FotosComponent> =
      this.dialog.open(FotosComponent, {
        autoFocus: false,
        hasBackdrop: hasBackdrop,
        height: height,
        width: width,
        data: { positionRelativeToElement: positionRelativeToElement, dados }
      })
    return dialogRef
  }

  setFotos(fotos: Fotos[]){
    this.fotos = fotos;
  }

  getFotos(){
    return this.fotos;
  }
}