import { Component, OnInit, Input, Inject, ElementRef, ViewChild } from '@angular/core';
import { Fotos } from '../../_model/foto/foto.model';
import { VistoriaFotoService } from './vistoria-foto.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CardVistoria } from 'app/_model/vistoria/cardVistoria.model';
declare var $:any;

@Component({
  selector: 'soma-foto',
  templateUrl: './foto.component.html',
  styleUrls: ['./foto.component.css']
})
export class FotoComponent implements OnInit {

  @ViewChild('container', { read: false }) public containerFotos: ElementRef;

  @Input() fotos: Fotos[];
  @Input() myButtonRef;

  listFotosCarrocel: Fotos[] = [];

  constructor(private dialogService: VistoriaFotoService,
    public dialogRef: MatDialogRef<FotoComponent>,
    @Inject(MAT_DIALOG_DATA) public data: CardVistoria
    ) { }

  ngOnInit() {
    this.fotos = this.data.fotos;
    this.preencherFotos();
    //this.openFotos(this.fotos[9]);
  }

  preencherFotos(){
    
    let fotosMiniatura: Fotos[] = [];
    this.fotos.filter(foto => fotosMiniatura.push(foto)); 

    if(fotosMiniatura.length > 0){
      fotosMiniatura.reverse();
      //fotosMiniatura.splice(6,fotosMiniatura.length);

      fotosMiniatura.filter(foto => {
        foto.isSelected = false;
        this.listFotosCarrocel.push(foto);
      });
    }
  }

  openFotos(fotoSelecionada){
    this.fotos.forEach(foto =>
      { foto.isSelected = false;
        if(fotoSelecionada.id === foto.id){
          foto.isSelected = true;
        }
        return foto;
      }
    );

      let dialogRef = this.dialogService.openDialog({
        positionRelativeToElement: this.myButtonRef,
        hasBackdrop: true,
        dados: this.fotos
      })
  
      dialogRef.afterClosed().subscribe(
        () => {
          dialogRef = null
        }
      )
  }

  ngAfterViewInit(){

    let vetor = ['a','p'];
    $(document).ready(function(){

    vetor.forEach(valor => {
      $(`${valor}`).click(function(){
        //$(this).hide();
        });
    })
    
      
    });

  }

  scrollWin(x){
   this.containerFotos.nativeElement.scrollBy(x, 0);
  }

  close(){
    this.dialogRef.close();
  }

}
