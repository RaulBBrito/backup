import { Component, ElementRef, Inject, OnInit, ViewChild } from '@angular/core'
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DOCUMENT } from '@angular/common'; 

export interface Fotos{
  id: number;
  imagem: string;
  data: string;
  isSelected: boolean;
}

@Component({
  selector: 'soma-fotos',
  templateUrl: './fotos.component.html',
  styleUrls: ['./fotos.component.css']
})
export class FotosComponent implements OnInit {
  @ViewChild('container', { read: false }) public containerFotos: ElementRef;
  fotos: Fotos[] = [];

  fotosCarrocel: Fotos[] = [];

  constructor(public dialogRef: MatDialogRef<FotosComponent>,
    @Inject(MAT_DIALOG_DATA) public options: { positionRelativeToElement: ElementRef, dados: Fotos[] },
    @Inject(DOCUMENT) private document) {

      this.fotos = this.options.dados.filter(foto => foto.isSelected);
      let fotosReverse: Fotos[] = []; 

      this.options.dados.forEach(foto => fotosReverse.push(foto));


      this.fotosCarrocel = fotosReverse.reverse();;
   
  }

  ngOnInit() {

    
  }
  scrollWin(x){
    console.log(x);
    
    //window.scrollBy(x, 0);
    //document.getElementById("foto-carrocel").scrollTop += 100;
   //document.getElementById("foto-carrocel").scrollBy(x, 0);
   
   this.containerFotos.nativeElement.scrollBy(x, 0);

  }

  close(){
    this.dialogRef.close();
  }

  addFoto(fotoSelecionada){
    let isFoto = false;

    this.fotos.filter(foto => {
      if(foto.id === fotoSelecionada.id)
        isFoto = true;
  });

  this.fotosCarrocel = this.fotosCarrocel.filter((foto) => {
    if(foto.id === fotoSelecionada.id && isFoto){
      foto.isSelected = !foto.isSelected
    }
  return foto;
  });

  
    if(!isFoto){

      

      if(this.fotos.length <= 3){
        this.fotos.push(fotoSelecionada);
        this.fotosCarrocel = this.fotosCarrocel.filter((foto) => {
          if(foto.id === fotoSelecionada.id){
            foto.isSelected = true
          }
        return foto;
        });
      }
    }else{
      this.fotos = this.fotos.filter(foto => foto.id !== fotoSelecionada.id);
    }

    
  }
}
