import { Component, OnInit } from '@angular/core';
import { LoginService } from '../../services/login.service'; 

import { VistoriaService } from '../../services/vistoria.service';

declare const $: any;
declare interface RouteInfo {
    path: string;
    title: string;
    icon: string;
    class: string;
    totalsinistro: string;
    routerApi: string;
}

export const ROUTES_VISTORIA: RouteInfo[] = [
  { path: '/vistoria-pendentes', title: 'Todas Pendentes',  icon: 'dashboard', class: '', totalsinistro: '4', routerApi: 'all'  },
  { path: '/vistoria-pendentes', title: 'Pendentes Não Lidas',  icon:'person', class: '', totalsinistro: '3', routerApi: 'unreaded'  },
  { path: '/vistoria-pendentes', title: 'Não Transmitidas',  icon:'content_paste', class: '', totalsinistro: '3', routerApi: 'untransmitted'  },
  { path: '/vistoria-transmitidas', title: 'Transmitidas',  icon:'library_books', class: '', totalsinistro: '', routerApi: 'transmitted'  },
];

export const ROUTES_OUTROS: RouteInfo[] = [
  { path: '/obter-vistoria', title: 'Obter Vistoria',  icon: 'dashboard', class: '', totalsinistro: '', routerApi: 'all' },
  { path: '/nova-vistoria', title: 'Nova Vistoria',  icon:'person', class: '', totalsinistro: '', routerApi: 'all'  },
  { path: '/vistoria-livre', title: 'Vistoria Livre',  icon:'content_paste', class: '', totalsinistro: '', routerApi: 'all' },
  { path: '/pendencias-confere', title: 'Pendências Confere',  icon:'library_books', class: '', totalsinistro: '' , routerApi: 'all' },
];

@Component({
  selector: 'soma-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})

export class SidebarComponent implements OnInit {

  menuItems: any[];
  menuItemsOutros: any[];    
  isLoginVerify: boolean = true;



  allVistorias: any[];
  
  constructor(private loginService: LoginService, private vistoriaService: VistoriaService){

    //this.menuItems = this.vistoriaService.getAll().filter(function (survey){
      //survey.
    //});
  }

  allPendentes(link: string){
    this.vistoriaService.getAllVistoria()
    .subscribe(
      (data)  => this.vistoriaService.setSurveyAll(data),
      (error) => console.log(error)
    );
  }

  ngOnInit() {
    this.menuItems = this.countScript();
    this.menuItemsOutros = ROUTES_OUTROS.filter(menuItem => menuItem);
    this.loginService.mostrarMenuEmitter.subscribe(
      mostrar => this.isLoginVerify = mostrar
    );
  }

  countScript(){
    return ROUTES_VISTORIA.filter(menuItem => 
      {
        if(menuItem.routerApi === 'all'){
          //menuItem.totalsinistro = this.vistoriaService.getAll().length.toString();
        }else{
          //menuItem.totalsinistro = '10'
        }
        return true;
        
      }
      );
  }

  isMobileMenu() {
    return false;
  };

  pendentesNotRead(){    
  }

}
