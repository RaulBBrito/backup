import { Component, ElementRef, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, Renderer2, ViewChild } from '@angular/core';
import { LoginService } from './components/services/login.service';
import { Router  } from '@angular/router';


import { NgxGalleryOptions, NgxGalleryImage, NgxGalleryAnimation } from 'ngx-gallery';
import {CroppedEvent} from 'ngx-photo-editor';
import * as jQuery from 'jquery';
import * as $ from 'jquery';

import { User } from './_model/user/user.model';
declare const PhotoViewer: any;
export interface DialogData {
  animal: string;
  name: string;
}

@Component({
  selector: 'soma-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  currentUser: User;

  constructor(private autService: LoginService, private router: Router){
    this.autService.currentUser.subscribe(x => this.currentUser = x);      
  }
  ngOnInit(){

    //declare const PhotoViewer: any;
    var items = [],
        options = {
          index: 0,
        };

        items.push({
          src: "https://farm1.staticflickr.com/313/31812080833_297acfbbd9_z.jpg",
          //title: $(this).attr('data-title')
        });

      new PhotoViewer(items, options);


    this.autService.currentUser.subscribe(x => this.currentUser = x);    
  }

  logout(){
    this.autService.logout();
    this.router.navigate(['/login']);
  }
}
