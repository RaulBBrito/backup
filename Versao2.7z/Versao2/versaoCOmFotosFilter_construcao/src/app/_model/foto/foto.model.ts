export class Fotos{
    id: number;
    imagem: string;
    data: string;
    isSelected: boolean;
  }