export class User {
    id: number;
    username: string;
    password: string;
    firstName: string;
    lastName: string;
    token: string;
    message_erro: string;

    usuario: string; 
    access_token: string;
    codigo: number;
}