export class Oficina{
    codigo: string;
    cnpjCpf: string;
    razaoSocial: string;
    nomeDeGuerra: string;
    cep: string;
    endereco: string;
    numero: string;
    complemento: string;
    uf: string;
    bairro: string;
    pontoReferencia: string;
    email: string;
    tel1ddd: string;
    tel1: string;
    ramal1: string;
    tel2ddd: string;
    tel2: string;
    ramal2: string;
    celularddd: string;
    celular: string;
    nextelddd: string;
    contato: string;
    
    //MOCKADO
    sinistro: string;
    enviadoPelaSeguradora: boolean;
}