export class InformacaoApolice{
    numeroSinistro: string;
    tipoSinistro: string;
    modelo: string;
    anoFabricacao: string;
    anoModelo: string;
    placa: string;
    naturezaSinsitro: string;
    dataSinistro: string;
    dataAviso: string;
    avisadoPor: string;
    condutor: {
        nome: string;
        idade: number
    }
    evento: string;
    danos: string;
    local: {
        endereco: string;
        bairro: string;
        cidade: string;
        cep: string;
        uf: string;
    }
    terceiros: [
        {
            numeroSinistro: string;
            tipoSinistro: string;
            modelo: string;
            anoFabricacao: string;
            anoModelo: string;
            placa: string;
            naturezaSinsitro: string;
            dataSinistro: string;
            dataAviso: string;
            avisadoPor: string;
            condutor: {
            nome: string;
            idade: number;
            },
            evento: string;
            danos: string;
            local: {
            endereco: string;
            bairro: string;
            cidade: string;
            cep: string;
            uf: string;
            }
        }
        ]
    }
    