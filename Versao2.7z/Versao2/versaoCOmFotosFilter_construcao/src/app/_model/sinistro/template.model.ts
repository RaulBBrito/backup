export class Template 
{
  codigo: number;
  nome: string;
  texto: string;
}